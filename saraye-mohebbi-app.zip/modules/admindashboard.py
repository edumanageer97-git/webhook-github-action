# modules/admindashboard.py - نسخه ۱۰۰٪ کارکرده و بدون خطا (کپی کن جایگزین کل فایل)
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QFrame, QScrollArea
)
from PySide6.QtCore import Qt, QTimer
from utils import db_connection

class AdminDashboard(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("سرای محبی - داشبورد مدیر ارشد ✈")
        self.resize(1600, 900)
        self.setStyleSheet("""
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #e0f2f1, stop:1 #b2dfdb);
            font-family: IRANSans, Tahoma;
            font-size: 14px;
        """)

        # اسکرول برای وقتی محتوا زیاد شد
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll_widget = QWidget()
        scroll.setWidget(scroll_widget)
        
        layout = QVBoxLayout(scroll_widget)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(25)

        # عنوان اصلی
        title = QLabel("<h1 style='color:#004d40;'>داشبورد مدیر ارشد - سرای محبی ✈</h1>")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        # کارت‌های آماری
        stats_layout = QHBoxLayout()
        stats = [
            ("تعداد کل دانش‌آموزان", "۴۲ نفر", "#e8f5e9"),
            ("حاضرین امروز", "۳۸ نفر", "#c8e6c9"),
            ("غایبین امروز", "۴ نفر", "#ffccbc"),
            ("کلاس‌های فعال", "۱۲ کلاس", "#b2dfdb")
        ]
        for text, value, color in stats:
            card = QFrame()
            card.setStyleSheet(f"""
                background: {color}; border-radius: 20px; padding: 20px;
                border: 2px solid #004d40;
            """)
            vbox = QVBoxLayout(card)
            vbox.addWidget(QLabel(f"<h2 style='margin:0; color:#004d40;'>{value}</h2>", alignment=Qt.AlignCenter))
            vbox.addWidget(QLabel(f"<h4 style='margin:5px; color:#00695c;'>{text}</h4>", alignment=Qt.AlignCenter))
            stats_layout.addWidget(card)
        layout.addLayout(stats_layout)

        # آخرین حضور و غیاب
        table_label = QLabel("<h2 style='color:#004d40;'>آخرین ورود و خروج‌ها</h2>")
        layout.addWidget(table_label)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["نام دانش‌آموز", "کلاس", "وضعیت", "ساعت", "تاریخ"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setStyleSheet("background:white; border-radius:15px; gridline-color:#004d40;")
        layout.addWidget(self.table)

        # دکمه‌های عملیاتی
        btn_layout = QHBoxLayout()
        buttons = [
            ("ثبت دانش‌آموز جدید", "#00695c"),
            ("اسکنر ورود و خروج", "#004d40"),
            ("گزارش‌گیری مالی", "#00796b"),
            ("مدیریت کلاس‌ها", "#00897b")
        ]
        for text, color in buttons:
            btn = QPushButton(text)
            btn.setStyleSheet(f"""
                background:{color}; color:white; padding:18px; border-radius:18px;
                font-size:16px; font-weight:bold; min-width:200px;
            """)
            btn.setCursor(Qt.PointingHandCursor)
            btn_layout.addWidget(btn)
        layout.addLayout(btn_layout)

        # تنظیم لی‌اوت اصلی
        main_layout = QVBoxLayout(self)
        main_layout.addWidget(scroll)

        # رفرش خودکار
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_data)
        self.timer.start(5000)
        self.refresh_data()

    def refresh_data(self):
        with db_connection() as conn:
            rows = conn.execute("""
                SELECT s.name, s.class, a.status, a.time, a.date
                FROM attendance a
                JOIN students s ON a.student_id = s.id
                ORDER BY a.id DESC LIMIT 15
            """).fetchall()

        self.table.setRowCount(len(rows))
        for i, row in enumerate(rows):
            status = "ورود" if "حاضر" in row["status"] else "خروج"
            color = "#e8f5e9" if status == "ورود" else "#ffebee"
            for j, text in enumerate([row["name"], row["class"] or "-", status, row["time"] or "-", row["date"]]):
                item = QTableWidgetItem(text)
                item.setBackground(Qt.GlobalColor.transparent if i % 2 else Qt.GlobalColor.white)
                self.table.setItem(i, j, item)