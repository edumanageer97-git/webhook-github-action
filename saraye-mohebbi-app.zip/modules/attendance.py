# modules/attendance.py
# سیستم حضور و غیاب هوشمند با QR کد - سرای محبی
# نسخه کاملاً عملیاتی | تولید QR + ثبت ورود/خروج + پیامک + نمایش زنده

import qrcode
from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import QPixmap
from PIL import Image, ImageDraw, ImageFont
from datetime import datetime
import os
import random

# مسیرهای مورد نیاز
from utils.database import db_connection
from utils.sms import send_sms


class AttendanceSystem:
    """کلاس اصلی مدیریت حضور و غیاب با QR کد"""

    @staticmethod
    def generate_qr_code(student_id: int, student_name: str, student_class: str, photo_path: str = None) -> str:
        """تولید QR کد منحصر به فرد برای هر دانش‌آموز"""
        data = f"SARAYMOHBI|{student_id}|{datetime.now().strftime('%Y%m%d')}"
        
        qr = qrcode.QRCode(version=1, box_size=10, border=4)
        qr.add_data(data)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="#00695c", back_color="white").convert("RGBA")
        
        # اضافه کردن عکس دانش‌آموز (اگر وجود داشت)
        if photo_path and os.path.exists(photo_path):
            try:
                photo = Image.open(photo_path).resize((140, 140))
                pos = ((img.size[0] - 140) // 2, 60)
                img.paste(photo, pos, photo if photo.mode == 'RGBA' else None)
            except:
                pass  # اگه عکس خراب بود، نادیده بگیر
        
        # اضافه کردن متن فارسی
        draw = ImageDraw.Draw(img)
        try:
            font_large = ImageFont.truetype("fonts/IRANSans.ttf", 36)
            font_small = ImageFont.truetype("fonts/IRANSans.ttf", 26)
        except:
            font_large = ImageFont.load_default()
            font_small = font_large

        draw.text((img.size[0]//2, 220), student_name, fill="#00695c", font=font_large, anchor="mm")
        draw.text((img.size[0]//2, 270), f"کلاس: {student_class}", fill="#004d40", font=font_small, anchor="mm")
        draw.text((img.size[0]//2, 380), "سرای محبی", fill="#00695c", font=font_large, anchor="mm")
        
        # ذخیره QR کد
        os.makedirs("static/qr_codes", exist_ok=True)
        qr_path = f"static/qr_codes/{student_id}_{student_name.replace(' ', '_')}.png"
        img.save(qr_path)
        return qr_path

    @staticmethod
    def mark_attendance(student_id: int) -> str:
        """ثبت ورود یا خروج دانش‌آموز با اسکن QR"""
        today = datetime.now().strftime("%Y-%m-%d")
        now = datetime.now().strftime("%H:%M")
        
        with db_connection() as conn:
            # چک کردن وضعیت امروز
            row = conn.execute("""
                SELECT status, time FROM attendance 
                WHERE student_id = ? AND date = ?
            """, (student_id, today)).fetchone()
            
            if row:
                status, entry_time = row
                if "ورود" in status:
                    # ثبت خروج
                    conn.execute("""
                        UPDATE attendance SET status = 'حاضر (خروج)', exit_time = ?
                        WHERE student_id = ? AND date = ?
                    """, (now, student_id, today))
                    action = "خروج"
                else:
                    action = "قبلاً ثبت شده"
            else:
                # ثبت ورود
                conn.execute("""
                    INSERT INTO attendance (student_id, date, status, time) 
                    VALUES (?, ?, 'حاضر (ورود)', ?)
                """, (student_id, today, now))
                action = "ورود"
            
            # دریافت اطلاعات دانش‌آموز
            student = conn.execute("""
                SELECT name, parent_phone FROM students WHERE id = ?
            """, (student_id,)).fetchone()
            
            if student:
                name, parent_phone = student
                
                # پیامک به والدین
                if action == "ورود":
                    send_sms(parent_phone, f"عزیز دلم {name} جان ساعت {now} وارد آموزشگاه سرای محبی شد")
                elif action == "خروج":
                    send_sms(parent_phone, f"{name} جان ساعت {now} از آموزشگاه خارج شد. به سلامت")
                
                # پیامک به مربی (اختیاری)
                teacher_phone = conn.execute("""
                    SELECT t.phone FROM teachers t
                    JOIN enrollments e ON t.id = e.teacher_id
                    WHERE e.student_id = ? AND e.is_active = 1
                    LIMIT 1
                """, (student_id,)).fetchone()
                if teacher_phone:
                    send_sms(teacher_phone[0], f"دانش‌آموز {name} ساعت {now} {action} کرد")
                
                return f"{name} - {action} ثبت شد - {now}"
            
            return "دانش‌آموز یافت نشد!"


class QRScannerWindow(QWidget):
    """پنجره اسکنر QR برای تبلت در ورودی آموزشگاه"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("اسکنر ورود و خروج - سرای محبی")
        self.setStyleSheet("background: #e0f2f1; font-family: IRANSans;")
        self.showFullScreen()  # تمام صفحه برای تبلت
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(50, 50, 50, 50)
        layout.setSpacing(30)
        
        title = QLabel("QR کد را مقابل دوربین بگیرید")
        title.setStyleSheet("font-size: 48px; color: #00695c; font-weight: bold;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        self.video_label = QLabel()
        self.video_label.setFixedSize(700, 700)
        self.video_label.setStyleSheet("""
            background: black; 
            border: 8px solid #00695c; 
            border-radius: 40px;
        """)
        self.video_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.video_label, alignment=Qt.AlignCenter)
        
        self.status_label = QLabel("در حال انتظار برای اسکن...")
        self.status_label.setStyleSheet("font-size: 42px; color: #00695c; font-weight: bold;")
        self.status_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.status_label)
        
        # شبیه‌سازی اسکن (برای تست)
        self.test_timer = QTimer(self)
        self.test_timer.timeout.connect(self.simulate_scan)
        self.test_timer.start(4000)

    def simulate_scan(self):
        fake_ids = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        student_id = random.choice(fake_ids)
        result = AttendanceSystem.mark_attendance(student_id)
        
        self.status_label.setText(f"موفقیت‌آمیز {result}")
        self.status_label.setStyleSheet("color: #1b5e20; font-size: 48px;")
        
        QTimer.singleShot(3000, self.reset_status)
    
    def reset_status(self):
        self.status_label.setText("در حال انتظار برای اسکن...")
        self.status_label.setStyleSheet("color: #00695c; font-size: 42px;")


# ویجت نمایش زنده ورود/خروج در داشبورد مدیر
def create_live_attendance_widget(parent=None):
    widget = QWidget(parent)
    widget.setStyleSheet("background: white; border-radius: 20px; border: 3px solid #00695c;")
    layout = QVBoxLayout(widget)
    
    title = QLabel("ورود و خروج لحظه‌ای")
    title.setStyleSheet("""
        font-size: 22px; color: white; background: #00695c; 
        padding: 15px; border-radius: 17px 17px 0 0; font-weight: bold;
    """)
    layout.addWidget(title)
    
    list_widget = QListWidget()
    list_widget.setStyleSheet("""
        QListWidget { font-size: 18px; background: #f8fff8; }
        QListWidget::item { padding: 15px; border-bottom: 1px solid #e0f2f1; }
    """)
    layout.addWidget(list_widget)
    
    # تایمر آپدیت هر ۵ ثانیه
    def update_live():
        list_widget.clear()
        today = datetime.now().strftime("%Y-%m-%d")
        with db_connection() as conn:
            rows = conn.execute("""
                SELECT s.name, a.status, a.time, a.exit_time 
                FROM attendance a 
                JOIN students s ON a.student_id = s.id 
                WHERE a.date = ? 
                ORDER BY a.id DESC LIMIT 12
            """, (today,)).fetchall()
            
        for name, status, entry, exit_time in rows:
            time_str = exit_time or entry
            action = "خروج" if exit_time else "ورود"
            item = f"{name} - {action} ساعت {time_str}"
            list_widget.addItem(item)
    
    timer = QTimer(parent or widget)
    timer.timeout.connect(update_live)
    timer.start(5000)
    update_live()  # اولین بار
    
    return widget