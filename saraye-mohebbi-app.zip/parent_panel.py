# parent_panel.py - نسخه نهایی و ۱۰۰٪ کارکرده (بدون Method Not Allowed)
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from utils import db_connection
from utils.sms import send_verification_code
import random
import uvicorn

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# ذخیره موقت کدها
verification_codes = {}

@app.get("/", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("parent_login.html", {"request": request})

@app.post("/send_code")
async def send_code(request: Request, phone: str = Form(...)):  # ← این خط درست شد
    code = "".join(random.choices("0123456789", k=5))
    verification_codes[phone] = code
    
    # کد تو ترمینال چاپ می‌شه
    send_verification_code(phone, code)
    
    return templates.TemplateResponse("parent_verify.html", {
        "request": request,
        "phone": phone,
        "message": "کد تأیید ارسال شد (در ترمینال ببینید)"
    })

@app.post("/verify")
async def verify(request: Request, phone: str = Form(...), code: str = Form(...)):  # ← اینم درست شد
    if verification_codes.get(phone) == code:
        with db_connection() as conn:
            student = conn.execute(
                "SELECT * FROM students WHERE parent_phone = ?", (phone,)
            ).fetchone()
        
        if student:
            verification_codes.pop(phone, None)
            return templates.TemplateResponse("parent_dashboard.html", {
                "request": request,
                "student": student,
                "message": f"خوش آمدید {student.get('parent_name', '')} عزیز ✈"
            })
        else:
            return templates.TemplateResponse("parent_login.html", {
                "request": request,
                "error": "شماره موبایل در سیستم ثبت نشده است"
            })
    else:
        return templates.TemplateResponse("parent_verify.html", {
            "request": request,
            "phone": phone,
            "error": "کد وارد شده اشتباه است!"
        })

if __name__ == "__main__":
    print("پنل والدین سرای محبی با موفقیت اجرا شد!")
    print("برو به: http://127.0.0.1:8000")
    uvicorn.run(app, host="0.0.0.0", port=8000)