# dialogs/LoginDialog.py - نسخه نهایی ۱۰۰٪ بدون خطا (کپی کن جایگزین کن)
from PySide6.QtWidgets import (
    QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPixmap, QIcon, QFont

class LoginDialog(QDialog):
    login_successful = Signal(str, str)  # role, username

    def __init__(self):
        super().__init__()
        self.setWindowTitle("سرای محبی - ورود به سیستم")
        self.resize(500, 650)
        self.setWindowIcon(QIcon("icons/logo_mahbi.svg"))  # یا logo.png

        # پس‌زمینه و استایل کلی
        self.setStyleSheet("""
            QDialog {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #e0f2f1, stop:1 #b2dfdb);
                font-family: IRANSans, Tahoma;
            }
            QLabel { color: #004d40; }
            QLineEdit {
                padding: 14px;
                font-size: 16px;
                border: 2px solid #00695c;
                border-radius: 12px;
                background: white;
            }
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #00796b, stop:1 #004d40);
                color:hover { background: #004d40; }
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(40, 30, 40, 40)
        layout.setSpacing(20)

        # لوگوی بزرگ وسط صفحه
        logo_label = QLabel()
        pixmap = QPixmap("icons/saray_mohebi_full.png")  # اسم دقیق فایلت رو بذار
        if pixmap.isNull():
            pixmap = QPixmap("icons/logo_mahbi.svg")  # بک‌آپ
        logo_label.setPixmap(pixmap.scaled(320, 140, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        logo_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(logo_label)

        # عنوان
        title = QLabel("سرای محبی")
        title.setFont(QFont("IRANSans", 32, QFont.Bold))
        title.setStyleSheet("color: #00695c;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        subtitle = QLabel("سیستم مدیریت هوشمند آموزشگاه")
        subtitle.setFont(QFont("IRANSans", 14))
        subtitle.setAlignment(Qt.AlignCenter)
        layout.addWidget(subtitle)

        # فیلدهای ورود
        self.username = QLineEdit()
        self.username.setPlaceholderText("نام کاربری (admin)")
        self.password = QLineEdit()
        self.password.setPlaceholderText("رمز عبور (1234)")
        self.password.setEchoMode(QLineEdit.Password)

        layout.addWidget(self.username)
        layout.addWidget(self.password)

        # دکمه ورود
        login_btn = QPushButton("ورود به داشبورد")
        login_btn.setFont(QFont("IRANSans", 16, QFont.Bold))
        login_btn.setStyleSheet("""
            QPushButton {
                background: #00695c;
                color: white;
                padding: 16px;
                border-radius: 16px;
                font-size: 18px;
            }
            QPushButton:hover {
                background: #004d40;
            }
        """)
        login_btn.clicked.connect(self.check_login)
        layout.addWidget(login_btn)

    def check_login(self):
        user = self.username.text().strip()
        pwd = self.password.text().strip()

        # کاربر پیش‌فرض برای تست سریع
        if user == "admin" and pwd == "1234":
            self.login_successful.emit("مدیر ارشد", user)
            self.accept()
            return

        # بقیه کاربران از دیتابیس
        from utils.database import db_connection
        with db_connection() as conn:
            row = conn.execute(
                "SELECT role FROM users WHERE username = ? AND password = ?",
                (user, pwd)
            ).fetchone()
            if row:
                self.login_successful.emit(row["role"], user)
                self.accept()
            else:
                QMessageBox.critical(self, "خطا", "نام کاربری یا رمز عبور اشتباه است")