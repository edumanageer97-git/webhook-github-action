# ایمپورت‌های استاندارد برای همه دیالوگ‌ها
from PySide6.QtWidgets import (
    QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout,
    QMessageBox, QFormLayout, QComboBox, QDateEdit, QTextEdit,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QGridLayout,
    QCheckBox, QSpinBox, QDoubleSpinBox, QFileDialog, QProgressBar
)
from PySide6.QtCore import Qt, QDate, Signal
from PySide6.QtGui import QFont, QPixmap, QIcon
class StudentDialog(QDialog):
    data_saved = Signal()  # برای رفرش لیست بعد از ذخیره

    def __init__(self, student_id=None, parent=None):
        super().__init__(parent)
        self.student_id = student_id
        self.setWindowTitle("افزودن فراگیر جدید" if not student_id else "ویرایش فراگیر")
        self.setFixedSize(560, 720)
        self.setModal(True)

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(12)

        # عنوان
        title = QLabel("اطلاعات فراگیر" if student_id else "ثبت‌نام فراگیر جدید")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #00695c;")
        title.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)

        # فیلدهای اصلی
        self.full_name = QLineEdit()
        self.national_id = QLineEdit()
        self.national_id.setPlaceholderText("اختیاری - فقط عدد")
        self.birth_date = QDateEdit()
        self.birth_date.setCalendarPopup(True)
        self.birth_date.setDate(QDate(2005, 1, 1))  # پیش‌فرض

        self.parent_name = QLineEdit()
        self.parent_phone = QLineEdit()
        self.parent_phone.setPlaceholderText("اجباری - موبایل والد")
        self.student_phone = QLineEdit()
        self.student_phone.setPlaceholderText("اختیاری - موبایل فراگیر")

        self.student_type = QComboBox()
        self.student_type.addItems([
            "کارآموز آزاد",
            "شطرنج‌باز هیئت",
            "کارآموز پتروشیمی",
            "کارآموز آریاساسول",
            "کارآموز سازمانی"
        ])

        self.requested_class = QComboBox()
        self.load_classes()  # پر کردن کلاس‌های فعال

        # خرید پک یا کتاب (برای رباتیک، شطرنج و ...)
        self.needs_package = QCheckBox("نیاز به پک/کتاب/تجهیزات دارد")
        self.package_items = QComboBox()
        self.package_items.addItems([
            "پک رباتیک مقدماتی (۱,۲۰۰,۰۰۰ تومان)",
            "کتاب شطرنج مقدماتی (۱۵۰,۰۰۰ تومان)",
            "پک رباتیک پیشرفته (۲,۸۰۰,۰۰۰ تومان)",
            "تجهیزات شطرنج حرفه‌ای (۴۵۰,۰۰۰ تومان)",
            "بدون پک"
        ])
        self.package_items.setEnabled(False)
        self.needs_package.stateChanged.connect(lambda state: self.package_items.setEnabled(state == Qt.Checked))

        # مالی
        self.total_fee = QSpinBox()
        self.total_fee.setRange(0, 20000000)
        self.total_fee.setSuffix(" تومان")
        self.total_fee.setValue(1500000)  # پیش‌فرض

        self.paid_amount = QSpinBox()
        self.paid_amount.setRange(0, 20000000)
        self.paid_amount.setSuffix(" تومان")

        self.remaining_debt = QLabel("۰ تومان")
        self.remaining_debt.setStyleSheet("font-weight: bold; color: red; font-size: 14px;")

        self.tracking_code = QLineEdit()
        self.tracking_code.setPlaceholderText("مثال: SAR1403-001")

        self.registration_date = QDateEdit()
        self.registration_date.setCalendarPopup(True)
        self.registration_date.setDate(QDate.currentDate())

        # اتصال محاسبه مانده بدهی
        self.total_fee.valueChanged.connect(self.calculate_debt)
        self.paid_amount.valueChanged.connect(self.calculate_debt)

        # افزودن به فرم
        def req(text):
            lbl = QLabel(text)
            lbl.setStyleSheet("color: red;")
            return lbl

        form.addRow(req("نام و نام خانوادگی *"), self.full_name)
        form.addRow("کد ملی", self.national_id)
        form.addRow("تاریخ تولد", self.birth_date)
        form.addRow(req("نام والد *"), self.parent_name)
        form.addRow(req("موبایل والد *"), self.parent_phone)
        form.addRow("موبایل فراگیر", self.student_phone)
        form.addRow("نوع فراگیر *", self.student_type)
        form.addRow("کلاس درخواستی", self.requested_class)
        form.addRow("", self.needs_package)
        form.addRow("پک/کتاب مورد نیاز", self.package_items)
        form.addRow("شهریه کل دوره", self.total_fee)
        form.addRow("مبلغ پرداختی", self.paid_amount)
        form.addRow("مانده بدهی:", self.remaining_debt)
        form.addRow("کد پیگیری", self.tracking_code)
        form.addRow("تاریخ ثبت‌نام", self.registration_date)

        main_layout.addLayout(form)

        # دکمه‌ها
        btn_box = QDialogButtonBox()
        self.save_btn = btn_box.addButton("ذخیره و بستن", QDialogButtonBox.AcceptRole)
        self.save_continue_btn = btn_box.addButton("ذخیره و ثبت‌نام بعدی", QDialogButtonBox.ActionRole)
        if student_id:
            self.delete_btn = btn_box.addButton("حذف فراگیر", QDialogButtonBox.RejectRole)
            self.delete_btn.setStyleSheet("background: #d32f2f; color: white;")
            self.delete_btn.clicked.connect(self.delete_student)
        btn_box.addButton(QDialogButtonBox.Cancel)

        btn_box.accepted.connect(self.save_student)
        self.save_continue_btn.clicked.connect(lambda: self.save_student(stay_open=True))
        btn_box.rejected.connect(self.reject)

        main_layout.addWidget(btn_box)

        # اگر ویرایش است، اطلاعات را بارگذاری کن
        if student_id:
            self.load_student_data()

    def load_classes(self):
        with db_connection() as conn:
            classes = conn.execute("""
                SELECT c.id, c.name || ' - ' || co.name || ' (' || t.name || ')' AS info
                FROM classes c
                JOIN courses co ON c.course_id = co.id
                JOIN terms t ON c.term_id = t.id
                WHERE c.status = 'در حال برگزاری' OR c.status = 'برنامه‌ریزی'
            """).fetchall()
            for cls in classes:
                self.requested_class.addItem(cls["info"], cls["id"])

    def load_student_data(self):
        with db_connection() as conn:
            student = conn.execute("SELECT * FROM students WHERE id = ?", (self.student_id,)).fetchone()
            if not student:
                return

            self.full_name.setText(student["full_name"] or "")
            self.national_id.setText(student["national_id"] or "")
            self.parent_name.setText(student["father_name"] or "")
            self.parent_phone.setText(student["parent_phone"] or "")
            self.student_phone.setText(student["phone"] or "")
            self.student_type.setCurrentText(student["student_type"] or "کارآموز آزاد")

            if student["birth_date"]:
                y, m, d = map(int, student["birth_date"].split('-'))
                self.birth_date.setDate(QDate(y, m, d))

            # بارگذاری ثبت‌نام و بدهی
            enrollment = conn.execute("""
                SELECT e.*, cl.name, co.name AS course_name
                FROM enrollments e
                JOIN classes cl ON e.class_id = cl.id
                JOIN courses co ON cl.course_id = co.id
                WHERE e.student_id = ? ORDER BY e.id DESC LIMIT 1
            """, (self.student_id,)).fetchone()

            if enrollment:
                self.total_fee.setValue(int(enrollment["total_fee"] or 0))
                self.paid_amount.setValue(int(enrollment["paid_amount"] or 0))
                self.tracking_code.setText(enrollment.get("tracking_code", "") or "")
                self.calculate_debt()

    def calculate_debt(self):
        total = self.total_fee.value()
        paid = self.paid_amount.value()
        debt = total - paid
        self.remaining_debt.setText(f"{debt:,} تومان")
        self.remaining_debt.setStyleSheet("font-weight: bold; color: " + ("red" if debt > 0 else "green"))

    def save_student(self, stay_open=False):
        # اعتبارسنجی
        if not all([self.full_name.text().strip(), self.parent_name.text().strip(), self.parent_phone.text().strip()]):
            QMessageBox.warning(self, "خطا", "فیلدهای ستاره‌دار اجباری هستند!")
            return

        with db_connection() as conn:
            try:
                if self.student_id:
                    # ویرایش
                    conn.execute("""
                        UPDATE students SET full_name=?, national_id=?, father_name=?, birth_date=?,
                        phone=?, parent_phone=?, student_type=? WHERE id=?
                    """, (
                        self.full_name.text().strip(),
                        self.national_id.text().strip() or None,
                        self.parent_name.text().strip(),
                        self.birth_date.date().toString("yyyy-MM-dd"),
                        self.student_phone.text().strip() or None,
                        self.parent_phone.text().strip(),
                        self.student_type.currentText(),
                        self.student_id
                    ))
                else:
                    # ثبت جدید
                    conn.execute("""
                        INSERT INTO students 
                        (full_name, national_id, father_name, birth_date, phone, parent_phone, student_type, registration_date)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        self.full_name.text().strip(),
                        self.national_id.text().strip() or None,
                        self.parent_name.text().strip(),
                        self.birth_date.date().toString("yyyy-MM-dd"),
                        self.student_phone.text().strip() or None,
                        self.parent_phone.text().strip(),
                        self.student_type.currentText(),
                        self.registration_date.date().toString("yyyy-MM-dd")
                    ))
                    self.student_id = conn.lastrowid

                # ثبت یا بروزرسانی ثبت‌نام در کلاس
                class_id = self.requested_class.currentData()
                if class_id:
                    existing = conn.execute("SELECT id FROM enrollments WHERE student_id = ? AND class_id = ?", 
                                          (self.student_id, class_id)).fetchone()
                    if existing:
                        conn.execute("""
                            UPDATE enrollments SET total_fee=?, paid_amount=?, status='ثبت‌نام شده'
                            WHERE id=?
                        """, (self.total_fee.value(), self.paid_amount.value(), existing["id"]))
                    else:
                        conn.execute("""
                            INSERT INTO enrollments (student_id, class_id, total_fee, paid_amount, registration_date, status)
                            VALUES (?, ?, ?, ?, ?, 'ثبت‌نام شده')
                        """, (self.student_id, class_id, self.total_fee.value(), self.paid_amount.value(),
                              self.registration_date.date().toString("yyyy-MM-dd")))

                QMessageBox.information(self, "موفقیت", "اطلاعات فراگیر با موفقیت ذخیره شد!")
                self.data_saved.emit()
                if not stay_open:
                    self.accept()
                else:
                    self.clear_form()

            except Exception as e:
                QMessageBox.critical(self, "خطا", f"خطا در ذخیره: {str(e)}")

    def clear_form(self):
        self.full_name.clear()
        self.national_id.clear()
        self.parent_name.clear()
        self.parent_phone.clear()
        self.student_phone.clear()
        self.total_fee.setValue(1500000)
        self.paid_amount.setValue(0)
        self.tracking_code.clear()
        self.needs_package.setChecked(False)

    def delete_student(self):
        reply = QMessageBox.question(self, "تأیید حذف", 
                                   f"آیا از حذف فراگیر «{self.full_name.text()}» اطمینان دارید؟\nاین عمل قابل بازگشت نیست!",
                                   QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            with db_connection() as conn:
                conn.execute("DELETE FROM students WHERE id = ?", (self.student_id,))
                conn.execute("DELETE FROM enrollments WHERE student_id = ?", (self.student_id,))
            QMessageBox.information(self, "حذف شد", "فراگیر با موفقیت حذف شد.")
            self.data_saved.emit()
            self.accept()
            
