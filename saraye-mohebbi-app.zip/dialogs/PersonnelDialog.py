# ایمپورت‌های استاندارد برای همه دیالوگ‌ها
from PySide6.QtWidgets import (
    QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout,
    QMessageBox, QFormLayout, QComboBox, QDateEdit, QTextEdit,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QGridLayout,
    QCheckBox, QSpinBox, QDoubleSpinBox, QFileDialog, QProgressBar
)
from PySide6.QtCore import Qt, QDate, Signal
from PySide6.QtGui import QFont, QPixmap, QIcon
class PersonnelDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("مدیریت پرسنل - سرای محبی")
        self.setFixedSize(1300, 750)
        self.setStyleSheet("font-family: IRANSans, Tahoma; font-size: 11pt;")

        layout = QVBoxLayout(self)

        # هدر
        header = QHBoxLayout()
        header.addWidget(QLabel("<h1>مدیریت پرسنل و دسترسی‌ها</h1>"))
        header.addStretch()
        add_btn = QPushButton("افزودن پرسنل جدید")
        add_btn.setStyleSheet("background:#00695c; color:white; padding:12px; font-size:14px;")
        add_btn.clicked.connect(self.add_personnel)
        header.addWidget(add_btn)
        layout.addLayout(header)

        # فیلتر نقش
        filter_layout = QHBoxLayout()
        filter_layout.addWidget(QLabel("نمایش بر اساس نقش:"))
        self.role_filter = QComboBox()
        self.role_filter.addItems(["همه", "مدیر ارشد", "مدیر داخلی", "مربی", "حسابدار", "ادمین پذیرش", "مشاور فروش"])
        self.role_filter.currentIndexChanged.connect(self.load_personnel)
        filter_layout.addWidget(self.role_filter)
        filter_layout.addStretch()
        layout.addLayout(filter_layout)

        # جدول پرسنل
        self.table = QTableWidget()
        self.table.setColumnCount(10)
        self.table.setHorizontalHeaderLabels([
            "نام و نام خانوادگی", "کد پرسنلی", "نقش", "حقوق ثابت", "درصد کلاس", 
            "شماره تماس", "وضعیت", "تاریخ استخدام", "فیش حقوقی", "عملیات"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)

        self.load_personnel()

    def load_personnel(self):
        role = self.role_filter.currentText()
        where = "" if role == "همه" else f"WHERE role = '{role}'"

        with db_connection() as conn:
            personnel = conn.execute(f"""
                SELECT id, full_name, personnel_code, role, base_salary, class_percentage,
                       phone, is_active, hire_date
                FROM personnel {where} ORDER BY hire_date DESC
            """).fetchall()

        self.table.setRowCount(len(personnel))
        for row, p in enumerate(personnel):
            status = "فعال" if p["is_active"] else "غیرفعال"
            status_color = "#e8f5e8" if p["is_active"] else "#ffebee"

            self.table.setItem(row, 0, QTableWidgetItem(p["full_name"]))
            self.table.setItem(row, 1, QTableWidgetItem(p["personnel_code"]))
            self.table.setItem(row, 2, QTableWidgetItem(p["role"]))
            self.table.setItem(row, 3, QTableWidgetItem(f"{p['base_salary']:,}"))
            self.table.setItem(row, 4, QTableWidgetItem(f"%{p['class_percentage']}"))
            self.table.setItem(row, 5, QTableWidgetItem(p["phone"]))
            
            status_item = QTableWidgetItem(status)
            status_item.setBackground(QColor(status_color))
            status_item.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(row, 6, status_item)
            
            self.table.setItem(row, 7, QTableWidgetItem(p["hire_date"]))

            # دکمه فیش حقوقی
            payslip_btn = QPushButton("فیش این ماه")
            payslip_btn.clicked.connect(lambda _, pid=p["id"]: TeacherPayslipDialog(pid).exec())
            self.table.setCellWidget(row, 8, payslip_btn)

            # دکمه‌های عملیات
            btns = QWidget()
            h = QHBoxLayout(btns)
            h.setContentsMargins(5,5,5,5)
            edit_btn = QPushButton("ویرایش")
            login_btn = QPushButton("ورود با این کاربر")
            h.addWidget(edit_btn)
            h.addWidget(login_btn)
            login_btn.clicked.connect(lambda _, pid=p["id"]: self.login_as_user(pid))
            self.table.setCellWidget(row, 9, btns)

    def add_personnel(self):
        dlg = AddPersonnelDialog(self)
        if dlg.exec():
            self.load_personnel()

    def login_as_user(self, user_id):
        # شبیه‌سازی ورود با نقش کاربر
        with db_connection() as conn:
            user = conn.execute("SELECT role FROM personnel WHERE id = ?", (user_id,)).fetchone()
        MainWindow.login_as_role(user["role"])
