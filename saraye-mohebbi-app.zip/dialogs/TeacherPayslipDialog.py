
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt, QDate
from PySide6.QtGui import QPixmap, QPainter
from PySide6.QtPrintSupport import QPrinter
import qrcode
from datetime import datetime
from PySide6.QtWidgets import (QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout, QMessageBox, QFormLayout, QComboBox, QDateEdit, QTextEdit, 
QTableWidget, QTableWidgetItem, QHeaderView)
from PySide6.QtCore import Qt
class TeacherPayslipDialog(QDialog):
    def __init__(self, teacher_id, month_year=None, parent=None):
        super().__init__(parent)
        self.teacher_id = teacher_id
        self.month_year = month_year or QDate.currentDate().toString("yyyy-MM")
        self.setWindowTitle(f"فیش حقوقی مربی - {self.month_year.replace('-', '/')}")
        self.setFixedSize(900, 750)
        self.setStyleSheet("font-family: IRANSans, Tahoma; font-size: 11pt;")

        self.teacher_data = self.load_teacher_data()
        self.salary_data = self.calculate_salary()

        layout = QVBoxLayout(self)
        layout.addWidget(self.create_payslip_widget())
        
        buttons = QHBoxLayout()
        print_btn = QPushButton("چاپ فیش")
        print_btn.setStyleSheet("background:#00695c; color:white; padding:12px; font-size:14px;")
        print_btn.clicked.connect(self.print_payslip)

        pdf_btn = QPushButton("ذخیره PDF")
        pdf_btn.setStyleSheet("background:#1976d2; color:white; padding:12px;")
        pdf_btn.clicked.connect(self.save_pdf)

        send_btn = QPushButton("ارسال به واتساپ")
        send_btn.setStyleSheet("background:#25d366; color:white; padding:12px;")
        
        buttons.addWidget(print_btn)
        buttons.addWidget(pdf_btn)
        buttons.addWidget(send_btn)
        buttons.addStretch()
        layout.addLayout(buttons)

    def load_teacher_data(self):
        with db_connection() as conn:
            teacher = conn.execute("""
                SELECT full_name, role, base_salary, class_percentage, national_id, phone
                FROM personnel WHERE id = ?
            """, (self.teacher_id,)).fetchone()
        return teacher

    def calculate_salary(self):
        year, month = self.month_year.split("-")
        with db_connection() as conn:
            # جلسات تدریس شده در این ماه
            sessions = conn.execute("""
                SELECT COUNT(*) as count, SUM(c.base_fee * c.student_count * 0.35) as class_income
                FROM sessions s
                JOIN classes c ON s.class_id = c.id
                WHERE s.teacher_id = ? AND strftime('%Y-%m', s.date) = ?
            """, (self.teacher_id, self.month_year)).fetchone()

            # پاداش و کسورات (ساده)
            bonus = 500000  # مثلاً پاداش حضور کامل
            deductions = 0

        base = self.teacher_data["base_salary"]
        percentage = self.teacher_data["class_percentage"] / 100
        class_income = sessions["class_income"] or 0
        class_bonus = class_income * percentage

        gross = base + class_bonus + bonus
        net = gross - deductions

        return {
            "sessions_count": sessions["count"] or 0,
            "class_bonus": int(class_bonus),
            "bonus": bonus,
            "deductions": deductions,
            "gross": int(gross),
            "net": int(net)
        }

    def create_payslip_widget(self):
        widget = QWidget()
        widget.setStyleSheet("""
            background:white; border:2px solid #00695c; border-radius:15px;
            padding:20px; margin:10px;
        """)
        layout = QVBoxLayout(widget)

        # هدر فیش
        header = QHBoxLayout()
        logo = QLabel()
        logo.setPixmap(QPixmap("logo.png").scaled(100, 100, Qt.KeepAspectRatio))
        header.addWidget(logo)

        title_box = QVBoxLayout()
        title_box.addWidget(QLabel("<h1 style='color:#00695c;'>سرای محبی</h1>"))
        title_box.addWidget(QLabel("<h2>فیش حقوقی مربی - بخش آموزش</h2>"))
        title_box.addWidget(QLabel(f"تاریخ: {datetime.now().strftime('%Y/%m/%d')}"))
        header.addLayout(title_box)
        header.addStretch()

        # QR Code
        qr = qrcode.QRCode()
        qr.add_data(f"TeacherID:{self.teacher_id}|Month:{self.month_year}|Net:{self.salary_data['net']}")
        qr.make()
        qr_img = qr.make_image(fill_color="#00695c", back_color="white")
        qr_pixmap = QPixmap.fromImage(qr_img.toqimage()).scaled(100, 100, Qt.KeepAspectRatio)
        qr_label = QLabel()
        qr_label.setPixmap(qr_pixmap)
        header.addWidget(qr_label)

        layout.addLayout(header)
        layout.addWidget(QLabel("<hr>"))

        # اطلاعات مربی
        info_grid = QGridLayout()
        info_grid.addWidget(QLabel("<b>نام و نام خانوادگی:</b>"), 0, 0)
        info_grid.addWidget(QLabel(self.teacher_data["full_name"]), 0, 1)
        info_grid.addWidget(QLabel("<b>کد ملی:</b>"), 0, 2)
        info_grid.addWidget(QLabel(self.teacher_data["national_id"]), 0, 3)

        info_grid.addWidget(QLabel("<b>سمت:</b>"), 1, 0)
        info_grid.addWidget(QLabel(self.teacher_data["role"]), 1, 1)
        info_grid.addWidget(QLabel("<b>تعداد جلسات تدریس:</b>"), 1, 2)
        info_grid.addWidget(QLabel(str(self.salary_data["sessions_count"])), 1, 3)

        layout.addLayout(info_grid)
        layout.addWidget(QLabel("<hr style='border:1px dashed #00695c;'>"))

        # جدول حقوق
        table = QTableWidget()
        table.setColumnCount(2)
        table.setHorizontalHeaderLabels(["شرح", "مبلغ (تومان)"])
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        table.setRowCount(7)

        items = [
            ("حقوق ثابت ماهانه", f"{self.teacher_data['base_salary']:,}"),
            (f"درصد از درآمد کلاس‌ها ({self.teacher_data['class_percentage']}%)", f"{self.salary_data['class_bonus']:,}"),
            ("پاداش حضور/عملکرد", f"{self.salary_data['bonus']:,}"),
            ("جمع ناخالص", f"{self.salary_data['gross']:,}"),
            ("کسورات (بیمه/مالیات)", f"{self.salary_data['deductions']:,}"),
            ("", ""),
            ("<b>خالص پرداختی</b>", f"<b style='color:#00695c; font-size:16pt;'>{self.salary_data['net']:,}</b>")
        ]

        for row, (desc, amount) in enumerate(items):
            table.setItem(row, 0, QTableWidgetItem(desc))
            item = QTableWidgetItem(amount)
            if "خالص" in desc:
                item.setForeground(Qt.white)
                item.setBackground(QColor("#00695c"))
            table.setItem(row, 1, item)

        table.setSpan(6, 0, 1, 2)
        table.item(6, 0).setBackground(QColor("#e8f5e8"))
        layout.addWidget(table)

        # امضا
        footer = QHBoxLayout()
        footer.addStretch()
        footer.addWidget(QLabel("امضای مدیر مالی: _________________"))
        footer.addWidget(QLabel("امضای مربی: _________________"))
        layout.addLayout(footer)

        note = QLabel("این فیش به صورت الکترونیکی صادر شده و نیازی به مهر ندارد.")
        note.setStyleSheet("color:gray; font-size:9pt;")
        layout.addWidget(note)

        return widget

    def print_payslip(self):
        printer = QPrinter(QPrinter.HighResolution)
        dialog = QPrintDialog(printer, self)
        if dialog.exec():
            painter = QPainter(printer)
            self.findChild(QWidget).render(painter)
            painter.end()
            QMessageBox.information(self, "موفقیت", "فیش با موفقیت چاپ شد!")

    def save_pdf(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "ذخیره فیش به صورت PDF", 
            f"فیش_حقوقی_{self.teacher_data['full_name']}_{self.month_year}.pdf",
            "PDF Files (*.pdf)"
        )
        if path:
            printer = QPrinter(QPrinter.HighResolution)
            printer.setOutputFormat(QPrinter.PdfFormat)
            printer.setOutputFileName(path)
            painter = QPainter(printer)
            self.findChild(QWidget).render(painter)
            painter.end()
            QMessageBox.information(self, "موفقیت", f"فیش در مسیر زیر ذخیره شد:\n{path}")

# ======================== فرم ثبت‌نام والدین - سرای محبی (نسخه نهایی ۲۰۲۵) ========================

class ParentEnrollmentDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("ثبت‌نام دانش‌آموز - سرای محبی")
        self.setFixedSize(1100, 780)
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        # مسیر عکس
        self.student_photo_path = None

        # پس‌زمینه اصلی
        self.bg = QWidget(self)
        self.bg.setStyleSheet("""
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                stop:0 #e0f8f5, stop:1 #b2dfdb);
            border-radius: 30px;
            border: 4px solid white;
        """)
        self.bg.resize(1100, 780)

        layout = QVBoxLayout(self)
        layout.addWidget(self.bg)
        layout.setContentsMargins(20, 20, 20, 40)

        main_layout = QVBoxLayout(self.bg)
        main_layout.setContentsMargins(40, 40, 40, 40)
        main_layout.setSpacing(30)

        # ========== هدر ==========
        header = QHBoxLayout()
        logo = QLabel()
        logo.setPixmap(QPixmap("logo.png").scaled(90, 90, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        logo.setStyleSheet("background: white; border-radius: 45px; padding: 10px;")

        title = QLabel("سرای محبی")
        title.setStyleSheet("color: #00695c; font-size: 42px; font-weight: bold;")
        title.setFont(QFont("Vazir", 42, QFont.Bold))

        subtitle = QLabel("فرم ثبت‌نام دانش‌آموز")
        subtitle.setStyleSheet("color: #004d40; font-size: 22px; margin-top: -10px;")
        subtitle.setFont(QFont("Vazir", 18))

        header.addWidget(logo)
        header.addWidget(title, alignment=Qt.AlignLeft)
        header.addStretch()
        header.addWidget(subtitle, alignment=Qt.AlignRight)
        main_layout.addLayout(header)

        # ========== تب‌ها ==========
        tabs = QTabWidget()
        tabs.setStyleSheet("""
            QTabWidget::pane { border: none; background: transparent; }
            QTabBar::tab {
                background: white;
                color: #00695c;
                padding: 16px 50px;
                margin: 5px;
                border-radius: 25px;
                font-size: 16px;
                font-weight: bold;
                min-width: 180px;
            }
            QTabBar::tab:selected {
                background: #00695c;
                color: white;
            }
        """)

        tabs.addTab(self.create_child_tab(), "۱. دانش‌آموز")
        tabs.addTab(self.create_parent_tab(), "۲. والدین")
        tabs.addTab(self.create_courses_tab(), "۳. دوره‌ها")
        tabs.addTab(self.create_final_tab(), "۴. تأیید")

        main_layout.addWidget(tabs, 1)

        # ========== دکمه نهایی ==========
        self.final_btn = QPushButton("تکمیل ثبت‌نام و صدور قبض")
        self.final_btn.setFixedHeight(70)
        self.final_btn.setStyleSheet("""
            QPushButton {
                background: #00695c;
                color: white;
                font-size: 22px;
                font-weight: bold;
                border-radius: 35px;
                border: 4px solid white;
            }
            QPushButton:hover {
                background: #004d40;
                transform: translateY(-3px);
                box-shadow: 0 15px 30px rgba(0,105,92,0.3);
            }
        """)
        self.final_btn.clicked.connect(self.complete_enrollment)
        main_layout.addWidget(self.final_btn, alignment=Qt.AlignCenter)

        # انیمیشن ورود
        self.animate_entrance()

    def animate_entrance(self):
        opacity = QGraphicsOpacityEffect(self.bg)
        self.bg.setGraphicsEffect(opacity)
        anim = QPropertyAnimation(opacity, b"opacity")
        anim.setDuration(800)
        anim.setStartValue(0)
        anim.setEndValue(1)
        anim.setEasingCurve(QEasingCurve.InOutQuart)
        anim.start()

    # ========== تب ۱: دانش‌آموز ==========
    def create_child_tab(self):
        widget = QWidget()
        widget.setStyleSheet("background: white; border-radius: 25px; padding: 30px;")
        layout = QGridLayout(widget)

        # عکس دانش‌آموز
        self.photo_label = QLabel()
        self.photo_label.setFixedSize(220, 220)
        self.photo_label.setStyleSheet("""
            border: 6px solid #00695c;
            border-radius: 110px;
            background: #e8f5e8;
        """)
        self.set_default_photo()
        layout.addWidget(self.photo_label, 0, 0, 4, 1, Qt.AlignCenter)

        upload_btn = QPushButton("آپلود عکس دانش‌آموز")
        upload_btn.setStyleSheet("background: #00695c; color: white; padding: 12px; border-radius: 25px;")
        upload_btn.clicked.connect(self.upload_photo)
        layout.addWidget(upload_btn, 4, 0, Qt.AlignCenter)

        # فرم
        fields = [
            ("نام", QLineEdit()),
            ("نام خانوادگی", QLineEdit()),
            ("تاریخ تولد", QDateEdit()),
            ("جنسیت", QComboBox()),
            ("مدرسه", QLineEdit()),
            ("پایه تحصیلی", QComboBox())
        ]

        combo = fields[3][1]; combo.addItems(["پسر", "دختر"])
        grade = fields[5][1]; grade.addItems(["پیش‌دبستانی", "اول", "دوم", "سوم", "چهارم", "پنجم", "ششم", "هفتم", "هشتم", "نهم", "دهم", "یازدهم", "دوازدهم"])
        fields[2][1].setCalendarPopup(True)
        fields[2][1].setDate(QDate(2015, 1, 1))

        row = 0
        for label_text, widget in fields:
            label = QLabel(f"{label_text} *")
            label.setStyleSheet("color: #00695c; font-size: 16px; font-weight: bold;")
            widget.setStyleSheet("padding: 15px; border: 2px solid #b2dfdb; border-radius: 20px; font-size: 15px;")
            widget.setFixedHeight(55)
            layout.addWidget(label, row, 1)
            layout.addWidget(widget, row, 2)
            row += 1

        self.child_name = fields[0][1]
        self.child_family = fields[1][1]

        return widget

    # ========== تب ۲: والدین ==========
    def create_parent_tab(self):
        widget = QWidget()
        widget.setStyleSheet("background: white; border-radius: 25px; padding: 40px;")
        layout = QFormLayout(widget)
        layout.setLabelAlignment(Qt.AlignRight)
        layout.setVerticalSpacing(25)

        fields = [
            ("نام و نام خانوادگی والد", QLineEdit()),
            ("شماره همراه", QLineEdit()),
            ("ایمیل (اختیاری)", QLineEdit()),
            ("شغل والد (اختیاری)", QLineEdit()),
            ("از چه طریقی با سرای محبی آشنا شدید؟", QComboBox())
        ]

        combo = fields[4][1]
        combo.addItems(["اینستاگرام", "معرفی دوست", "وبسایت", "پیاده‌روی", "تبلیغات", "تلگرام", "سایر"])

        for label_text, widget in fields:
            label = QLabel(label_text)
            label.setStyleSheet("color: #00695c; font-size: 17px; font-weight: bold;")
            widget.setStyleSheet("padding: 18px; border: 2px solid #b2dfdb; border-radius: 25px; font-size: 16px;")
            widget.setFixedHeight(65)
            layout.addRow(label, widget)

        self.parent_name = fields[0][1]
        self.parent_phone = fields[1][1]
        self.how_knew = fields[4][1]

        return widget

    # ========== تب ۳: دوره‌ها ==========
    def create_courses_tab(self):
        widget = QWidget()
        widget.setStyleSheet("background: white; border-radius: 25px; padding: 30px;")
        layout = QVBoxLayout(widget)

        title = QLabel("دوره‌های مورد علاقه را انتخاب کنید")
        title.setStyleSheet("color: #00695c; font-size: 24px; font-weight: bold;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        grid = QGridLayout()
        self.course_checks = {}
        courses = [
            ("رباتیک مقدماتی", 2800000), ("رباتیک پیشرفته", 3500000),
            ("شطرنج حرفه‌ای", 2500000), ("سفالگری", 1600000),
            ("برنامه‌نویسی پایتون", 3200000), ("المپیاد ریاضی", 4200000),
            ("زبان انگلیسی", 2200000), ("خلاقیت و هوش", 1900000)
        ]

        for i, (name, fee) in enumerate(courses):
            cb = QCheckBox(f"{name}\n{fee:,} تومان")
            cb.setStyleSheet("font-size: 18px; padding: 20px; background: #e8f5e8; border-radius: 20px;")
            self.course_checks[name] = {"check": cb, "fee": fee}
            cb.toggled.connect(self.update_total)
            grid.addWidget(cb, i//2, i%2)

        layout.addLayout(grid)
        layout.addStretch()

        total_box = QGroupBox("مبلغ کل")
        total_box.setStyleSheet("background: #00695c; color: white; border-radius: 25px; padding: 25px; font-size: 20px;")
        total_layout = QHBoxLayout(total_box)
        self.total_label = QLabel("۰ تومان")
        self.total_label.setStyleSheet("font-size: 32px; font-weight: bold;")
        total_layout.addWidget(QLabel("مبلغ قابل پرداخت:"))
        total_layout.addStretch()
        total_layout.addWidget(self.total_label)
        layout.addWidget(total_box)

        self.selected_courses = []

        return widget

    def update_total(self):
        total = sum(info["fee"] for info in self.course_checks.values() if info["check"].isChecked())
        self.total_label.setText(f"{total:,} تومان")
        self.selected_courses = [name for name, info in self.course_checks.items() if info["check"].isChecked()]

    # ========== تب ۴: تأیید ==========
    def create_final_tab(self):
        widget = QWidget()
        widget.setStyleSheet("background: white; border-radius: 25px; padding: 40px;")
        layout = QVBoxLayout(widget)

        layout.addWidget(QLabel("لطفاً اطلاعات را بررسی کنید:"), alignment=Qt.AlignCenter)
        self.summary = QLabel("در حال بارگذاری...")
        self.summary.setStyleSheet("background: #e8f5e8; padding: 30px; border-radius: 20px; font-size: 18px;")
        layout.addWidget(self.summary)

        self.agree_check = QCheckBox("تمامی قوانین و شرایط سرای محبی را مطالعه کرده و می‌پذیرم")
        self.agree_check.setStyleSheet("font-size: 18px; color: #00695c; font-weight: bold;")
        layout.addWidget(self.agree_check)

        return widget

    # ========== آپلود عکس ==========
    def upload_photo(self):
        path, _ = QFileDialog.getOpenFileName(self, "انتخاب عکس", "", "Images (*.png *.jpg *.jpeg)")
        if path:
            self.student_photo_path = path
            pixmap = QPixmap(path).scaled(220, 220, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            rounded = QPixmap(220, 220)
            rounded.fill(Qt.transparent)
            painter = QPainter(rounded)
            painter.setRenderHint(QPainter.Antialiasing)
            painter.setClipPath(painter.drawEllipse(0, 0, 220, 220))
            painter.drawPixmap(0, 0, pixmap)
            painter.end()
            self.photo_label.setPixmap(rounded)

    def set_default_photo(self):
        pixmap = QPixmap(220, 220)
        pixmap.fill(Qt.transparent)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setBrush(QColor("#00695c"))
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(30, 30, 160, 160)
        painter.setFont(QFont("Vazir", 16, QFont.Bold))
        painter.setPen(Qt.white)
        painter.drawText(pixmap.rect(), Qt.AlignCenter, "عکس\nدانش‌آموز")
        painter.end()
        self.photo_label.setPixmap(pixmap)

    # ========== تکمیل ثبت‌نام ==========
    def complete_enrollment(self):
        if not self.agree_check.isChecked():
            QMessageBox.warning(self, "تأیید", "لطفاً قوانین را تأیید کنید")
            return
        if not self.selected_courses:
            QMessageBox.warning(self, "دوره", "حداقل یک دوره انتخاب کنید")
            return

        QMessageBox.information(self, "تبریک!", 
            f"<h2 style='color:#00695c;'>ثبت‌نام با موفقیت انجام شد!</h2>"
            f"<p>دانش‌آموز: {self.child_name.text()} {self.child_name.text()}</p>"
            f"<p>تعداد دوره: {len(self.selected_courses)}</p>"
            f"<p>به زودی با شما تماس می‌گیریم</p>"
        )
        self.accept()


