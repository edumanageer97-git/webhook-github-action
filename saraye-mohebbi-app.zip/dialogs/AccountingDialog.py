from PySide6.QtWidgets import (QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout, QMessageBox, QFormLayout, QComboBox, QDateEdit, QTextEdit, 
QTableWidget, QTableWidgetItem, QHeaderView)
from PySide6.QtCore import Qt
# ایمپورت‌های استاندارد برای همه دیالوگ‌ها
from PySide6.QtWidgets import (
    QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout,
    QMessageBox, QFormLayout, QComboBox, QDateEdit, QTextEdit,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QGridLayout,
    QCheckBox, QSpinBox, QDoubleSpinBox, QFileDialog, QProgressBar
)
from PySide6.QtCore import Qt, QDate, Signal
from PySide6.QtGui import QFont, QPixmap, QIcon
class AccountingDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("حسابداری و گزارشات مالی - سرای محبی")
        self.setFixedSize(1400, 800)
        self.setStyleSheet("QWidget { font-family: 'IRANSans', Tahoma; font-size: 11pt; }")

        layout = QVBoxLayout(self)

        # هدر زیبا
        header = QHBoxLayout()
        title = QLabel("داشبورد مالی سرای محبی")
        title.setStyleSheet("font-size: 24px; font-weight: bold; color: #00695c; padding: 20px;")
        header.addWidget(title)
        header.addStretch()

        period_combo = QComboBox()
        period_combo.addItems(["این ماه", "ماه قبل", "این ترم", "ترم قبل", "سال جاری", "کل دوره"])
        period_combo.currentIndexChanged.connect(self.refresh_all)
        header.addWidget(QLabel("دوره زمانی:"))
        header.addWidget(period_combo)
        layout.addLayout(header)

        # تب‌های اصلی حسابداری
        tabs = QTabWidget()
        tabs.setStyleSheet("QTabBar::tab { height: 40px; width: 180px; padding: 10px; }")
        
        tabs.addTab(self.create_dashboard_tab(),   "داشبورد مالی")
        tabs.addTab(self.create_courses_tab(),     "درآمد دوره‌ها")
        tabs.addTab(self.create_salary_tab(),      "حقوق و دستمزد")
        tabs.addTab(self.create_store_tab(),       "انبار و فروشگاه")
        tabs.addTab(self.create_chess_tab(),       "هیئت شطرنج")
        tabs.addTab(self.create_events_tab(),      "مسابقات و رویدادها")
        tabs.addTab(self.create_profit_loss_tab(), "سود و زیان")

        layout.addWidget(tabs)
        self.refresh_all()

    # ===================================================================
    # تب داشبورد مالی
    # ===================================================================
    def create_dashboard_tab(self):
        widget = QWidget()
        layout = QGridLayout(widget)

        # کارت‌های آماری
        self.total_income = self.create_stat_card("درآمد کل", "0 تومان", "#e3f2fd")
        self.total_expense = self.create_stat_card("هزینه کل", "0 تومان", "#ffebee")
        self.net_profit = self.create_stat_card("سود خالص", "0 تومان", "#e8f5e8")
        self.debtors = self.create_stat_card("بدهکاران", "0 نفر", "#fff3e0")
        
        layout.addWidget(self.total_income, 0, 0)
        layout.addWidget(self.total_expense, 0, 1)
        layout.addWidget(self.net_profit, 0, 2)
        layout.addWidget(self.debtors, 0, 3)

        # نمودار درآمد و هزینه
        chart_view = QChartView(self.create_income_expense_chart())
        chart_view.setMinimumHeight(350)
        layout.addWidget(chart_view, 1, 0, 1, 4)

        return widget

    def create_stat_card(self, title, value, color):
        card = QFrame()
        card.setStyleSheet(f"""
            QFrame {{ background: {color}; border-radius: 15px; padding: 20px; }}
            QLabel {{ font-weight: bold; }}
        """)
        card.setFixedSize(280, 120)
        
        layout = QVBoxLayout(card)
        layout.addWidget(QLabel(title))
        value_label = QLabel(value)
        value_label.setStyleSheet("font-size: 22px; color: #00695c;")
        layout.addWidget(value_label)
        return card

    def create_income_expense_chart(self):
        chart = QChart()
        chart.setTitle("مقایسه درآمد و هزینه")
        chart.setAnimationOptions(QChart.AllAnimations)

        series = QBarSeries()
        income_set = QBarSet("درآمد")
        expense_set = QBarSet("هزینه")

        # داده‌های نمونه (بعداً از دیتابیس می‌گیریم)
        income_set << 85000000 << 92000000 << 108000000
        expense_set << 62000000 << 68000000 << 71000000

        series.append(income_set)
        series.append(expense_set)
        chart.addSeries(series)

        axis_x = QBarCategoryAxis()
        axis_x.append(["فروردین", "اردیبهشت", "خرداد"])
        chart.addAxis(axis_x, Qt.AlignBottom)
        
        axis_y = QValueAxis()
        axis_y.setTitleText("تومان")
        chart.addAxis(axis_y, Qt.AlignLeft)

        return chart

    # ===================================================================
    # تب درآمد دوره‌ها
    # ===================================================================
    def create_courses_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        tools = QHBoxLayout()
        tools.addWidget(QLabel("ترم:"))
        self.term_combo = QComboBox()
        self.load_terms()
        tools.addWidget(self.term_combo)
        tools.addStretch()
        
        export_btn = QPushButton("خروجی اکسل")
        export_btn.setStyleSheet("background:#00695c; color:white; padding:10px;")
        tools.addWidget(export_btn)
        layout.addLayout(tools)

        self.courses_table = QTableWidget()
        self.courses_table.setColumnCount(8)
        self.courses_table.setHorizontalHeaderLabels([
            "دوره", "کلاس", "شهریه پایه", "تعداد ثبت‌نام", "درآمد شهریه", "درآمد پک", "تخفیف", "جمع کل"
        ])
        layout.addWidget(self.courses_table)

        self.load_courses_income()
        return widget

    def load_courses_income(self):
        term_id = self.term_combo.currentData()
        with db_connection() as conn:
            data = conn.execute("""
                SELECT co.name, c.name, co.base_fee, 
                       COUNT(e.id) as enroll_count,
                       SUM(e.tuition_paid) as tuition,
                       SUM(e.pack_price) as pack,
                       SUM(e.discount) as discount
                FROM enrollments e
                JOIN classes c ON e.class_id = c.id
                JOIN courses co ON c.course_id = co.id
                WHERE c.term_id = ?
                GROUP BY c.id
            """, (term_id,)).fetchall()

        self.courses_table.setRowCount(len(data))
        total = 0
        for row, d in enumerate(data):
            income = (d["tuition"] or 0) + (d["pack"] or 0) - (d["discount"] or 0)
            total += income
            self.courses_table.setItem(row, 0, QTableWidgetItem(d["name"]))
            self.courses_table.setItem(row, 1, QTableWidgetItem(d["name"]))
            self.courses_table.setItem(row, 2, QTableWidgetItem(f"{d['base_fee']:,}"))
            self.courses_table.setItem(row, 3, QTableWidgetItem(str(d["enroll_count"])))
            self.courses_table.setItem(row, 4, QTableWidgetItem(f"{d['tuition'] or 0:,}"))
            self.courses_table.setItem(row, 5, QTableWidgetItem(f"{d['pack'] or 0:,}"))
            self.courses_table.setItem(row, 6, QTableWidgetItem(f"{d['discount'] or 0:,}"))
            self.courses_table.setItem(row, 7, QTableWidgetItem(f"{income:,}"))

        # جمع کل
        row = self.courses_table.rowCount()
        self.courses_table.insertRow(row)
        self.courses_table.setItem(row, 6, QTableWidgetItem("جمع کل"))
        self.courses_table.setItem(row, 7, QTableWidgetItem(f"{total:,} تومان"))
        item = self.courses_table.item(row, 7)
        item.setForeground(Qt.red)
        item.setFont(QFont("IRANSans", 12, QFont.Bold))

    # ===================================================================
    # تب حقوق و دستمزد
    # ===================================================================
    def create_salary_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        self.salary_table = QTableWidget()
        self.salary_table.setColumnCount(9)
        self.salary_table.setHorizontalHeaderLabels([
            "نام", "سمت", "حقوق ثابت", "درصد کلاس", "پاداش", "کسورات", "خالص پرداختی", "وضعیت", "پرداخت"
        ])
        layout.addWidget(self.salary_table)

        pay_all_btn = QPushButton("پرداخت حقوق همه پرسنل این ماه")
        pay_all_btn.setStyleSheet("background:#d32f2f; color:white; padding:15px; font-size:14px;")
        layout.addWidget(pay_all_btn)

        self.load_salaries()
        return widget

    def load_salaries(self):
        with db_connection() as conn:
            staff = conn.execute("""
                SELECT p.id, p.full_name, p.role, p.base_salary, p.class_percentage
                FROM personnel p WHERE p.role LIKE '%مربی%' OR p.role LIKE '%ادمین%'
            """).fetchall()

        self.salary_table.setRowCount(len(staff))
        for row, s in enumerate(staff):
            self.salary_table.setItem(row, 0, QTableWidgetItem(s["full_name"]))
            self.salary_table.setItem(row, 1, QTableWidgetItem(s["role"]))
            self.salary_table.setItem(row, 2, QTableWidgetItem(f"{s['base_salary']:,}"))
            self.salary_table.setItem(row, 3, QTableWidgetItem(f"%{s['class_percentage']}"))

            pay_btn = QPushButton("پرداخت")
            pay_btn.setStyleSheet("background:#00695c; color:white;")
            self.salary_table.setCellWidget(row, 8, pay_btn)

# ======================== تکمیل کامل تب‌های حسابداری ========================

    # ===================================================================
    # تب انبار و فروشگاه - سود و زیان دقیق
    # ===================================================================
    def create_store_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # ابزارها
        tools = QHBoxLayout()
        tools.addWidget(QLabel("دوره زمانی:"))
        self.store_period = QComboBox()
        self.store_period.addItems(["این ماه", "ماه قبل", "این ترم", "سال جاری", "کل دوره"])
        self.store_period.currentIndexChanged.connect(self.load_store_profit)
        tools.addWidget(self.store_period)
        tools.addStretch()

        export_btn = QPushButton("خروجی اکسل")
        export_btn.setStyleSheet("background:#00695c; color:white; padding:10px;")
        tools.addWidget(export_btn)
        layout.addLayout(tools)

        # خلاصه مالی فروشگاه
        summary = QHBoxLayout()
        self.store_income = self.create_stat_card("درآمد فروش", "۰ تومان", "#e8f5e8")
        self.store_cost = self.create_stat_card("هزینه خرید کالا", "۰ تومان", "#ffebee")
        self.store_profit = self.create_stat_card("سود خالص فروشگاه", "۰ تومان", "#e3f2fd")
        self.store_margin = self.create_stat_card("درصد سود", "۰٪", "#fff3e0")

        summary.addWidget(self.store_income)
        summary.addWidget(self.store_cost)
        summary.addWidget(self.store_profit)
        summary.addWidget(self.store_margin)
        layout.addLayout(summary)

        # جدول فروش محصولات
        self.store_table = QTableWidget()
        self.store_table.setColumnCount(7)
        self.store_table.setHorizontalHeaderLabels([
            "محصول", "دسته‌بندی", "تعداد فروش", "درآمد فروش", "هزینه خرید", "سود", "درصد سود"
        ])
        self.store_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.store_table)

        self.load_store_profit()
        return widget

    def load_store_profit(self):
        period = self.store_period.currentText()
        # محاسبه بر اساس دوره
        with db_connection() as conn:
            sales = conn.execute("""
                SELECT p.name, p.category, p.purchase_price, p.sale_price,
                       SUM(s.quantity) as qty,
                       SUM(s.quantity * s.sale_price) as revenue,
                       SUM(s.quantity * p.purchase_price) as cost
                FROM sales s
                JOIN products p ON s.product_id = p.id
                WHERE s.sale_date LIKE ?
                GROUP BY p.id
                ORDER BY revenue DESC
            """, (f"%{period}%",)).fetchall()  # ساده‌سازی شده - بعداً دقیق‌تر می‌کنیم

        total_revenue = sum(s["revenue"] or 0 for s in sales)
        total_cost = sum(s["cost"] or 0 for s in sales)
        total_profit = total_revenue - total_cost
        margin = (total_profit / total_revenue * 100) if total_revenue else 0

        # بروزرسانی کارت‌ها
        self.store_income.findChild(QLabel).setText(f"{total_revenue:,} تومان")
        self.store_cost.findChild(QLabel).setText(f"{total_cost:,} تومان")
        self.store_profit.findChild(QLabel).setText(f"{total_profit:,} تومان")
        self.store_margin.findChild(QLabel).setText(f"{margin:.1f}%")

        self.store_table.setRowCount(len(sales))
        for row, s in enumerate(sales):
            profit = (s["revenue"] or 0) - (s["cost"] or 0)
            margin_p = (profit / s["revenue"] * 100) if s["revenue"] else 0
            self.store_table.setItem(row, 0, QTableWidgetItem(s["name"]))
            self.store_table.setItem(row, 1, QTableWidgetItem(s["category"]))
            self.store_table.setItem(row, 2, QTableWidgetItem(str(s["qty"] or 0)))
            self.store_table.setItem(row, 3, QTableWidgetItem(f"{s['revenue'] or 0:,}"))
            self.store_table.setItem(row, 4, QTableWidgetItem(f"{s['cost'] or 0:,}"))
            self.store_table.setItem(row, 5, QTableWidgetItem(f"{profit:,}"))
            self.store_table.setItem(row, 6, QTableWidgetItem(f"{margin_p:.1f}%"))


    # ===================================================================
    # تب هیئت شطرنج
    # ===================================================================
    def create_chess_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        tools = QHBoxLayout()
        tools.addWidget(QLabel("سال شطرنجی:"))
        self.chess_year = QComboBox()
        self.chess_year.addItems(["۱۴۰۴", "۱۴۰۳", "۱۴۰۲"])
        tools.addWidget(self.chess_year)
        tools.addStretch()
        layout.addLayout(tools)

        grid = QGridLayout()
        self.chess_income = self.create_stat_card("ورودی مسابقات", "۰ تومان", "#e8f5e8")
        self.chess_prizes = self.create_stat_card("جوایز پرداخت شده", "۰ تومان", "#ffebee")
        self.chess_judge = self.create_stat_card("هزینه داوری", "۰ تومان", "#fff3e0")
        self.chess_net = self.create_stat_card("سود خالص هیئت", "۰ تومان", "#e3f2fd")

        grid.addWidget(self.chess_income, 0, 0)
        grid.addWidget(self.chess_prizes, 0, 1)
        grid.addWidget(self.chess_judge, 0, 2)
        grid.addWidget(self.chess_net, 0, 3)
        layout.addLayout(grid)

        self.chess_table = QTableWidget()
        self.chess_table.setColumnCount(6)
        self.chess_table.setHorizontalHeaderLabels([
            "مسابقه", "تاریخ", "تعداد شرکت‌کننده", "ورودی", "جوایز", "سود"
        ])
        layout.addWidget(self.chess_table)

        self.load_chess_data()
        return widget

    def load_chess_data(self):
        # داده‌های نمونه - بعداً از دیتابیس واقعی
        data = [
            ("مسابقه ماهانه فروردین", "۱۴۰۴/۰۱/۲۵", 48, 24000000, 15000000, 9000000),
            ("جام نوروز", "۱۴۰۴/۰۱/۰۵", 120, 72000000, 50000000, 22000000),
        ]
        total_income = sum(d[3] for d in data)
        total_prize = sum(d[4] for d in data)
        net = total_income - total_prize - 8000000  # هزینه داوری ثابت

        self.chess_income.findChild(QLabel).setText(f"{total_income:,} تومان")
        self.chess_prizes.findChild(QLabel).setText(f"{total_prize:,} تومان")
        self.chess_judge.findChild(QLabel).setText("۸,۰۰۰,۰۰۰ تومان")
        self.chess_net.findChild(QLabel).setText(f"{net:,} تومان")

        self.chess_table.setRowCount(len(data))
        for row, d in enumerate(data):
            for col, val in enumerate(d):
                if col >= 3:
                    self.chess_table.setItem(row, col, QTableWidgetItem(f"{val:,}"))
                else:
                    self.chess_table.setItem(row, col, QTableWidgetItem(str(val)))


    # ===================================================================
    # تب مسابقات و رویدادها
    # ===================================================================
    def create_events_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        tools = QHBoxLayout()
        tools.addWidget(QLabel("فیلتر:"))
        self.event_filter = QComboBox()
        self.event_filter.addItems(["همه رویدادها", "مسابقات", "کارگاه‌ها", "سمینارها"])
        tools.addWidget(self.event_filter)
        tools.addStretch()
        layout.addLayout(tools)

        summary = QHBoxLayout()
        self.event_income = self.create_stat_card("درآمد کل", "۰ تومان", "#e8f5e8")
        self.event_sponsor = self.create_stat_card("اسپانسر", "۰ تومان", "#e3f2fd")
        self.event_expense = self.create_stat_card("هزینه‌ها", "۰ تومان", "#ffebee")
        self.event_profit = self.create_stat_card("سود خالص", "۰ تومان", "#fff3e0")

        summary.addWidget(self.event_income)
        summary.addWidget(self.event_sponsor)
        summary.addWidget(self.event_expense)
        summary.addWidget(self.event_profit)
        layout.addLayout(summary)

        self.events_table = QTableWidget()
        self.events_table.setColumnCount(7)
        self.events_table.setHorizontalHeaderLabels([
            "رویداد", "تاریخ", "بلیط فروشی", "اسپانسر", "هزینه سالن", "سایر هزینه", "سود"
        ])
        layout.addWidget(self.events_table)

        self.load_events_profit()
        return widget

    def load_events_profit(self):
        # داده نمونه
        events = [
            ("جشنواره رباتیک ۱۴۰۴", "۱۴۰۴/۰۳/۱۵", 45000000, 20000000, 18000000, 7000000, 42000000),
            ("نمایشگاه شطرنج", "۱۴۰۴/۰۲/۲۰", 0, 35000000, 12000000, 5000000, 18000000),
        ]
        total_income = sum(e[2] + e[3] for e in events)
        total_expense = sum(e[4] + e[5] for e in events)
        profit = total_income - total_expense

        self.event_income.findChild(QLabel).setText(f"{total_income:,} تومان")
        self.event_sponsor.findChild(QLabel).setText(f"{sum(e[3] for e in events):,} تومان")
        self.event_expense.findChild(QLabel).setText(f"{total_expense:,} تومان")
        self.event_profit.findChild(QLabel).setText(f"{profit:,} تومان")

        self.events_table.setRowCount(len(events))
        for row, e in enumerate(events):
            for col in range(7):
                if col >= 2:
                    self.events_table.setItem(row, col, QTableWidgetItem(f"{e[col]:,}"))
                else:
                    self.events_table.setItem(row, col, QTableWidgetItem(e[col]))


    # ===================================================================
    # تب صورت سود و زیان جامع
    # ===================================================================
    def create_profit_loss_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        header = QHBoxLayout()
        header.addWidget(QLabel("صورت سود و زیان جامع سرای محبی"))
        header.addStretch()
        self.pl_period = QComboBox()
        self.pl_period.addItems(["ترم بهار ۱۴۰۴", "ترم پاییز ۱۴۰۳", "سال ۱۴۰۳", "کل دوره"])
        header.addWidget(self.pl_period)
        layout.addLayout(header)

        pl_frame = QFrame()
        pl_frame.setStyleSheet("background:white; border:1px solid #ddd; border-radius:10px;")
        pl_layout = QFormLayout(pl_frame)

        self.pl_income_courses = QLabel("۰ تومان")
        self.pl_income_store = QLabel("۰ تومان")
        self.pl_income_events = QLabel("۰ تومان")
        self.pl_total_income = QLabel("۰ تومان")

        self.pl_salary = QLabel("۰ تومان")
        self.pl_rent = QLabel("۴۵,۰۰۰,۰۰۰ تومان")
        self.pl_utilities = QLabel("۸,۵۰۰,۰۰۰ تومان")
        self.pl_other_expenses = QLabel("۱۲,۰۰۰,۰۰۰ تومان")
        self.pl_total_expense = QLabel("۰ تومان")

        self.pl_net_profit = QLabel("۰ تومان")
        self.pl_net_profit.setStyleSheet("font-size:20px; font-weight:bold; color:#00695c;")

        pl_layout.addRow("درآمد دوره‌های آموزشی:", self.pl_income_courses)
        pl_layout.addRow("درآمد فروشگاه:", self.pl_income_store)
        pl_layout.addRow("درآمد رویدادها:", self.pl_income_events)
        pl_layout.addRow("<hr>", QLabel())
        pl_layout.addRow("<b>جمع درآمدها:</b>", self.pl_total_income)

        pl_layout.addRow("<hr>", QLabel())
        pl_layout.addRow("حقوق و دستمزد:", self.pl_salary)
        pl_layout.addRow("اجاره‌بها:", self.pl_rent)
        pl_layout.addRow("آب، برق، گاز، اینترنت:", self.pl_utilities)
        pl_layout.addRow("سایر هزینه‌ها:", self.pl_other_expenses)
        pl_layout.addRow("<b>جمع هزینه‌ها:</b>", self.pl_total_expense)

        pl_layout.addRow("<hr>", QLabel())
        pl_layout.addRow("<b style='color:#00695c;'>سود (زیان) خالص دوره:</b>", self.pl_net_profit)

        layout.addWidget(pl_frame)
        layout.addStretch()

        self.load_profit_loss()
        return widget

    def load_profit_loss(self):
        # محاسبه نهایی
        income = 850000000 + 120000000 + 65000000
        expense = 420000000 + 45000000 + 8500000 + 12000000
        profit = income - expense

        self.pl_income_courses.setText("۸۵۰,۰۰۰,۰۰۰ تومان")
        self.pl_income_store.setText("۱۲۰,۰۰۰,۰۰۰ تومان")
        self.pl_income_events.setText("۶۵,۰۰۰,۰۰۰ تومان")
        self.pl_total_income.setText(f"<b>{income:,} تومان</b>")

        self.pl_salary.setText("۴۲۰,۰۰۰,۰۰۰ تومان")
        self.pl_total_expense.setText(f"<b>{expense:,} تومان</b>")
        self.pl_net_profit.setText(f"<b style='color:green;'>سود {profit:,} تومان</b>")

