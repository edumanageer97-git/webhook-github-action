
import os
from PySide6.QtWidgets import *
# ایمپورت‌های استاندارد برای همه دیالوگ‌ها
from PySide6.QtWidgets import (
    QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout,
    QMessageBox, QFormLayout, QComboBox, QDateEdit, QTextEdit,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QGridLayout,
    QCheckBox, QSpinBox, QDoubleSpinBox, QFileDialog, QProgressBar
)
from PySide6.QtCore import Qt, QDate, Signal
from PySide6.QtGui import QFont, QPixmap, QIcon

# مسیر ذخیره عکس‌ها (می‌تونی تغییر بدی)
STUDENT_PHOTOS_DIR = "student_photos"
os.makedirs(STUDENT_PHOTOS_DIR, exist_ok=True)

# فقط این متد رو به کلاس ParentEnrollmentDialog قبلی اضافه کن
# یا کامل جایگزین کن با این نسخه بهبودیافته

class ParentEnrollmentDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("ثبت‌نام دانش‌آموز جدید - سرای محبی")
        self.setFixedSize(1150, 780)
        self.setStyleSheet("background: #e0f2f1; font-family: IRANSans, Tahoma;")

        self.student_photo_path = None  # مسیر عکس انتخاب شده
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        # هدر (همون قبلی)
        header = QHBoxLayout()
        logo = QLabel()
        logo.setPixmap(QPixmap("logo.png").scaled(100, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        header.addWidget(logo)

        title_box = QVBoxLayout()
        title_box.addWidget(QLabel("<h1 style='color:#00695c;'>سرای محبی</h1>"))
        title_box.addWidget(QLabel("<h2>فرم ثبت‌نام دانش‌آموز</h2>"))
        header.addLayout(title_box)
        header.addStretch()
        layout.addLayout(header)
        layout.addWidget(self.create_horizontal_line())

        tabs = QTabWidget()
        tabs.addTab(self.create_child_tab_with_photo(), "۱. اطلاعات دانش‌آموز")
        tabs.addTab(self.create_parent_tab(), "۲. اطلاعات والد")
        tabs.addTab(self.create_courses_tab(), "۳. انتخاب دوره")
        tabs.addTab(self.create_payment_tab(), "۴. پرداخت و تأیید")
        layout.addWidget(tabs)

        # دکمه‌های پایین
        buttons = QHBoxLayout()
        buttons.addStretch()
        self.prev_btn = QPushButton("قبلی")
        self.next_btn = QPushButton("بعدی")
        self.final_btn = QPushButton("تکمیل ثبت‌نام و صدور قبض")
        self.final_btn.setStyleSheet("background:#25d366; color:white; padding:18px; border-radius:30px; font-size:18px; font-weight:bold;")
        self.final_btn.setFixedHeight(65)
        self.final_btn.clicked.connect(self.complete_enrollment)
        self.final_btn.setVisible(False)

        buttons.addWidget(self.prev_btn)
        buttons.addWidget(self.next_btn)
        buttons.addWidget(self.final_btn)
        layout.addLayout(buttons)

        tabs.currentChanged.connect(lambda i: self.update_buttons(i, tabs))

    # تب ۱ با آپلود عکس
    def create_child_tab_with_photo(self):
        widget = QWidget()
        main_layout = QVBoxLayout(widget)

        # بخش عکس
        photo_frame = QGroupBox("عکس دانش‌آموز (اختیاری اما توصیه می‌شود)")
        photo_frame.setStyleSheet("background:white; border-radius:15px; padding:20px;")
        photo_layout = QHBoxLayout(photo_frame)

        # پیش‌نمایش عکس
        self.photo_label = QLabel()
        self.photo_label.setFixedSize(220, 220)
        self.photo_label.setStyleSheet("border: 3px dashed #00695c; border-radius: 110px; background:#f5fffa;")
        default_pixmap = QPixmap(220, 220)
        default_pixmap.fill(Qt.transparent)
        painter = QPainter(default_pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setBrush(QColor("#00695c"))
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(40, 40, 140, 140)
        painter.setFont(QFont("IRANSans", 18, QFont.Bold))
        painter.setPen(Qt.white)
        painter.drawText(default_pixmap.rect(), Qt.AlignCenter, "عکس\nدانش‌آموز")
        painter.end()
        self.photo_label.setPixmap(default_pixmap)
        self.photo_label.setAlignment(Qt.AlignCenter)

        # دکمه‌های آپلود
        btn_layout = QVBoxLayout()
        upload_btn = QPushButton("آپلود از گالری")
        upload_btn.setStyleSheet("background:#00695c; color:white; padding:15px; border-radius:25px; font-size:14px;")
        upload_btn.clicked.connect(self.upload_photo)

        camera_btn = QPushButton("گرفتن عکس با دوربین")
        camera_btn.setStyleSheet("background:#004d40; color:white; padding:15px; border-radius:25px; font-size:14px;")
        camera_btn.clicked.connect(self.take_photo)

        remove_btn = QPushButton("حذف عکس")
        remove_btn.setStyleSheet("background:#d32f2f; color:white; padding:12px; border-radius:20px;")
        remove_btn.clicked.connect(self.remove_photo)

        btn_layout.addWidget(upload_btn)
        btn_layout.addWidget(camera_btn)
        btn_layout.addWidget(remove_btn)
        btn_layout.addStretch()

        photo_layout.addWidget(self.photo_label)
        photo_layout.addLayout(btn_layout)
        main_layout.addWidget(photo_frame)

        # فرم اطلاعات کودک
        form = QFormLayout()
        self.child_name = QLineEdit()
        self.child_family = QLineEdit()
        self.child_birthdate = QDateEdit(); self.child_birthdate.setCalendarPopup(True)
        self.child_birthdate.setDate(QDate(2015, 1, 1))
        self.child_gender = QComboBox(); self.child_gender.addItems(["پسر", "دختر"])
        self.child_school = QLineEdit()
        self.child_grade = QComboBox()
        self.child_grade.addItems(["پیش‌دبستانی", "اول", "دوم", "سوم", "چهارم", "پنجم", "ششم", "هفتم", "هشتم", "نهم", "دهم", "یازدهم", "دوازدهم"])

        form.addRow("نام *", self.child_name)
        form.addRow("نام خانوادگی *", self.child_family)
        form.addRow("تاریخ تولد *", self.child_birthdate)
        form.addRow("جنسیت *", self.child_gender)
        form.addRow("مدرسه", self.child_school)
        form.addRow("پایه تحصیلی *", self.child_grade)

        main_layout.addLayout(form)
        return widget

    def upload_photo(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "انتخاب عکس دانش‌آموز", "", "تصاویر (*.png *.jpg *.jpeg *.bmp)"
        )
        if file_path:
            self.set_photo(file_path)

    def take_photo(self):
        # شبیه‌سازی دوربین (در ویندوز/لینوکس/مک واقعی کار می‌کنه با QCamera)
        QMessageBox.information(self, "دوربین", "در نسخه کامل با وب‌کم یا دوربین تبلت فعال می‌شود")
        # برای تست:
        self.set_photo("sample_student.jpg")  # یه عکس نمونه بذار تو پوشه

    def set_photo(self, file_path):
        if not file_path or not os.path.exists(file_path):
            return

        # کپی عکس با نام یکتا
        ext = os.path.splitext(file_path)[1]
        student_name = f"{self.child_name.text()}_{self.child_family.text()}".strip() or "student"
        safe_name = "".join(c for c in student_name if c.isalnum() or c in " _-")
        new_filename = f"{safe_name}_{QDate.currentDate().toString('yyyyMMdd')}{ext}"
        new_path = os.path.join(STUDENT_PHOTOS_DIR, new_filename)

        # کپی و تغییر اندازه
        pixmap = QPixmap(file_path)
        if pixmap.width() > 800:
            pixmap = pixmap.scaled(800, 800, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        pixmap.save(new_path, quality=90)

        self.student_photo_path = new_path

        # نمایش پیش‌نمایش دایره‌ای
        rounded = QPixmap(220, 220)
        rounded.fill(Qt.transparent)
        painter = QPainter(rounded)
        painter.setRenderHint(QPainter.Antialiasing)
        path = QPainterPath()
        path.addEllipse(0, 0, 220, 220)
        painter.setClipPath(path)
        painter.drawPixmap(0, 0, 220, 220, pixmap.scaled(220, 220, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        painter.end()
        self.photo_label.setPixmap(rounded)

    def remove_photo(self):
        self.student_photo_path = None
        self.photo_label.setPixmap(self.get_default_photo())

    def get_default_photo(self):
        pixmap = QPixmap(220, 220)
        pixmap.fill(Qt.transparent)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setBrush(QColor("#00695c"))
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(40, 40, 140, 140)
        painter.setFont(QFont("IRANSans", 18, QFont.Bold))
        painter.setPen(Qt.white)
        painter.drawText(pixmap.rect(), Qt.AlignCenter, "عکس\nدانش‌آموز")
        painter.end()
        return pixmap

   def complete_enrollment(self):
    # ========== اعتبارسنجی نهایی ==========
    if not all([
        self.child_name.text().strip(),
        self.child_family.text().strip(),
        self.parent_name.text().strip(),
        self.parent_phone.text().strip(),
        self.selected_courses,
        self.agree_check.isChecked()
    ]):
        QMessageBox.warning(self, "خطا", "لطفاً تمام فیلدهای اجباری را پر کنید و قوانین را تأیید نمایید.")
        return

    if not self.selected_courses:
        QMessageBox.warning(self, "دوره انتخاب نشده", "حداقل یک دوره باید انتخاب شود!")
        return

    # ========== محاسبه مبلغ نهایی با تخفیف ==========
    total_fee = sum(self.course_checks[course]["fee"] for course in self.selected_courses)
    payment_method = "full" if self.payment_method.checkedId() == "full" else "installment" if self.payment_method.checkedId() == "installment" else "later"

    discount = 0
    if payment_method == "full":
        discount = int(total_fee * 0.05)  # ۵٪ تخفیف
    final_amount = total_fee - discount

    # ========== تولید کد پیگیری منحصر به فرد ==========
    from datetime import datetime
    tracking_code = f"MH{datetime.now().strftime('%y%m%d')}{datetime.now().microsecond // 1000:03d}"

    # ========== ذخیره در دیتابیس ==========
    photo_path = self.student_photo_path if self.student_photo_path else "student_photos/default.png"

    try:
        with db_connection() as conn:
            cursor = conn.cursor()

            # ثبت دانش‌آموز
            cursor.execute("""
                INSERT INTO students 
                (first_name, last_name, birth_date, gender, grade, school,
                 parent_name, parent_phone, parent_email, parent_job, source,
                 photo_path, register_date, tracking_code, payment_method, total_fee, discount, final_amount)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                self.child_name.text().strip(),
                self.child_family.text().strip(),
                self.child_birthdate.date().toString("yyyy-MM-dd"),
                self.child_gender.currentText(),
                self.child_grade.currentText(),
                self.child_school.text().strip() or None,
                self.parent_name.text().strip(),
                self.parent_phone.text().strip(),
                self.parent_email.text().strip() or None,
                self.parent_job.text().strip() or None,
                self.how_knew.currentText(),
                photo_path,
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                tracking_code,
                payment_method,
                total_fee,
                discount,
                final_amount
            ))

            student_id = cursor.lastrowid

            # ثبت دوره‌های انتخاب شده
            for course in self.selected_courses:
                cursor.execute("""
                    INSERT INTO enrollments (student_id, course_name, fee, status)
                    VALUES (?, ?, ?, 'ثبت‌نام شده')
                """, (student_id, course, self.course_checks[course]["fee"]))

            conn.commit()

    except Exception as e:
        QMessageBox.critical(self, "خطای دیتابیس", f"خطا در ذخیره اطلاعات:\n{e}")
        return

    # ========== اضافه شدن به CRM به عنوان ثبت‌نام موفق ==========
    try:
        with db_connection() as conn:
            conn.execute("""
                INSERT INTO leads 
                (child_name, parent_name, phone, course_interest, source, stage, register_date, tracking_code)
                VALUES (?, ?, ?, ?, ?, 'ثبت‌نام موفق', ?, ?)
            """, (
                f"{self.child_name.text()} {self.child_family.text()}",
                self.parent_name.text(),
                self.parent_phone.text(),
                ", ".join(self.selected_courses),
                self.how_knew.currentText(),
                datetime.now().strftime("%Y-%m-%d"),
                tracking_code
            ))
    except: pass  # اگر جدول leads نباشه، خطا نده

    # ========== نمایش قبض نهایی زیبا با عکس ==========
    photo_html = f'<img src="{photo_path}" width="120" style="border-radius:60px; border:4px solid #00695c;">' if os.path.exists(photo_path) else "عکس دانش‌آموز"

    receipt_html = f"""
    <div style="font-family: IRANSans; direction: rtl; text-align:center; padding:20px; background:white; border-radius:20px;">
        <h1 style="color:#00695c;">سرای محبی</h1>
        <h2 style="color:#004d40;">ثبت‌نام با موفقیت انجام شد!</h2>
        <hr style="border:2px dashed #00695c;">
        {photo_html}
        <h3>{self.child_name.text()} {self.child_family.text()}</h3>
        <p><b>کد پیگیری:</b> <span style="font-size:18px; color:#d32f2f;">{tracking_code}</span></p>
        <p><b>دوره‌های ثبت‌نامی:</b> {', '.join(self.selected_courses)}</p>
        <p><b>مبلغ کل:</b> {total_fee:,} تومان</p>
        {"<p style='color:green;'><b>تخفیف ۵٪ پرداخت کامل:</b> " + f"{discount:,} تومان</p>" if discount else ""}
        <p style="font-size:22px; color:#00695c;"><b>مبلغ قابل پرداخت: {final_amount:,} تومان</b></p>
        <p style="color:gray;">به زودی پیامک و تماس خوش‌آمدگویی دریافت خواهید کرد</p>
        <p style="margin-top:30px; color:#004d40;">با آرزوی موفقیت برای فرزند دلبندتان</p>
    </div>
    """

    msg = QMessageBox(self)
    msg.setWindowTitle("تبریک! ثبت‌نام موفق")
    msg.setTextFormat(Qt.RichText)
    msg.setText(receipt_html)
    msg.setIcon(QMessageBox.Information)
    msg.setStandardButtons(QMessageBox.Ok | QMessageBox.Print)
    msg.button(QMessageBox.Print).clicked.connect(lambda: self.print_receipt(receipt_html, tracking_code))
    msg.exec()

    # ========== پیامک خوش‌آمدگویی (شبیه‌سازی) ==========
    print(f"[پیامک ارسال شد] به {self.parent_phone.text()}: سلام {self.parent_name.text()} عزیز، فرزندتان {self.child_name.text()} با کد {tracking_code} در سرای محبی ثبت‌نام شد.")

    # ========== بستن فرم ==========
    self.accept()
      

