# ایمپورت‌های استاندارد برای همه دیالوگ‌ها
from PySide6.QtWidgets import (
    QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout,
    QMessageBox, QFormLayout, QComboBox, QDateEdit, QTextEdit,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QGridLayout,
    QCheckBox, QSpinBox, QDoubleSpinBox, QFileDialog, QProgressBar
)
from PySide6.QtCore import Qt, QDate, Signal
from PySide6.QtGui import QFont, QPixmap, QIcon
class TermDialog(QDialog):
    data_saved = Signal()

    def __init__(self, term_id=None, parent=None):
        super().__init__(parent)
        self.term_id = term_id
        self.setWindowTitle("ترم جدید" if not term_id else "ویرایش ترم")
        self.setFixedSize(460, 380)
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        title = QLabel("ترم جدید آموزشی" if not term_id else "ویرایش ترم")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #00695c;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)

        self.name = QLineEdit()
        self.name.setPlaceholderText("مثال: پاییز ۱۴۰۴")
        self.start_date = QDateEdit()
        self.start_date.setCalendarPopup(True)
        self.start_date.setDate(QDate.currentDate())
        self.end_date = QDateEdit()
        self.end_date.setCalendarPopup(True)
        self.end_date.setDate(QDate.currentDate().addDays(90))
        self.is_active = QCheckBox("ترم جاری و فعال")
        self.is_active.setChecked(True)

        form.addRow("نام ترم *", self.name)
        form.addRow("تاریخ شروع *", self.start_date)
        form.addRow("تاریخ پایان *", self.end_date)
        form.addRow("", self.is_active)

        layout.addLayout(form)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(self.save_term)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

        if term_id:
            self.load_term()

    def load_term(self):
        with db_connection() as conn:
            term = conn.execute("SELECT * FROM terms WHERE id = ?", (self.term_id,)).fetchone()
            if term:
                self.name.setText(term["name"])
                self.is_active.setChecked(bool(term["is_active"]))
                if term["start_date"]:
                    y, m, d = map(int, term["start_date"].split('-'))
                    self.start_date.setDate(QDate(y, m, d))
                if term["end_date"]:
                    y, m, d = map(int, term["end_date"].split('-'))
                    self.end_date.setDate(QDate(y, m, d))

    def save_term(self):
        if not self.name.text().strip():
            QMessageBox.warning(self, "خطا", "نام ترم الزامی است!")
            return

        with db_connection() as conn:
            try:
                if self.term_id:
                    conn.execute("""
                        UPDATE terms SET name=?, start_date=?, end_date=?, is_active=?
                        WHERE id=?
                    """, (
                        self.name.text().strip(),
                        self.start_date.date().toString("yyyy-MM-dd"),
                        self.end_date.date().toString("yyyy-MM-dd"),
                        int(self.is_active.isChecked()),
                        self.term_id
                    ))
                else:
                    conn.execute("""
                        INSERT INTO terms (name, start_date, end_date, is_active)
                        VALUES (?, ?, ?, ?)
                    """, (
                        self.name.text().strip(),
                        self.start_date.date().toString("yyyy-MM-dd"),
                        self.end_date.date().toString("yyyy-MM-dd"),
                        int(self.is_active.isChecked())
                    ))
                QMessageBox.information(self, "موفقیت", "ترم با موفقیت ذخیره شد.")
                self.data_saved.emit()
                self.accept()
            except Exception as e:
                QMessageBox.critical(self, "خطا", f"خطا در ذخیره: {str(e)}")


# -------------------------------------------------------------------------------
# 2. CourseDialog - دوره‌های سرای محبی (با لیست کامل و واقعی)
# -------------------------------------------------------------------------------
class CourseDialog(QDialog):
    data_saved = Signal()

    def __init__(self, course_id=None, parent=None):
        super().__init__(parent)
        self.course_id = course_id
        self.setWindowTitle("دوره جدید" if not course_id else "ویرایش دوره")
        self.setFixedSize(520, 580)
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        title = QLabel("دوره آموزشی جدید" if not course_id else "ویرایش دوره")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #00695c;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)

        self.name = QLineEdit()
        self.code = QLineEdit()
        self.code.setPlaceholderText("مثال: ROB101")
        
        self.category = QComboBox()
        self.category.addItems(sorted([
            "رباتیک خلاق", "رباتیک مقدماتي","رباتیک پيشرفته" "شطرنج مقدماتی", " (هیئت) شطرنج پیشرفته", "شطرنج حرفه‌ای (هیئت)",
            "نقاشی کودک", "نقاشی نوجوان","نقاشی بزرگسال", "سفالگری", "برنامه‌نویسی کودکان (Scratch)", "برنامه‌نویسی نوجوانان (Python)",
            "چرتکه ذهنی", "زبان انگلیسی کودکان", "زبان انگلیسی نوجوانان", "ICDL (مهارت‌های هفت‌گانه)", "عکاسی دیجیتال",
            "داوري درجه 3 شطرنج", "آمادگی المپیاد کامپیوتر", "آمادگی مسابقات شطرنج",
            "فن بیان و سخنرانی", "فنون مذاکره", "MBA و مديريت (کارآفرینی)", "هوش مالی و سرمایه‌گذاری",
            "ورکشاپ ها و کارگاه هاي کوتاه مدت", "آموزش مربیگری شطرنج درجه ۳", "آموزش مربیگری شطرنج درجه ۲",
            "داوری شطرنج درجه ۳", "دوره‌های درون‌سازمانی سفارشی"
        ]))

        self.duration = QSpinBox()
        self.duration.setRange(10, 300)
        self.duration.setSuffix(" ساعت")
        self.duration.setValue(40)

        self.base_fee = QSpinBox()
        self.base_fee.setRange(0, 20000000)
        self.base_fee.setSuffix(" تومان")
        self.base_fee.setValue(1800000)

        self.description = QTextEdit()
        self.description.setMaximumHeight(100)

        form.addRow("نام دوره *", self.name)
        form.addRow("کد دوره", self.code)
        form.addRow("دسته‌بندی *", self.category)
        form.addRow("مدت دوره (ساعت) *", self.duration)
        form.addRow("شهریه پایه *", self.base_fee)
        form.addRow("توضیحات", self.description)

        layout.addLayout(form)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(self.save_course)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

        if course_id:
            self.load_course()

    def load_course(self):
        with db_connection() as conn:
            course = conn.execute("SELECT * FROM courses WHERE id = ?", (self.course_id,)).fetchone()
            if course:
                self.name.setText(course["name"])
                self.code.setText(course["code"] or "")
                self.category.setCurrentText(course["category"])
                self.duration.setValue(course["duration"] or 40)
                self.base_fee.setValue(course["base_fee"] or 1800000)
                self.description.setPlainText(course["description"] or "")

    def save_course(self):
        if not self.name.text().strip():
            QMessageBox.warning(self, "خطا", "نام دوره الزامی است!")
            return

        with db_connection() as conn:
            try:
                if self.course_id:
                    conn.execute("""
                        UPDATE courses SET name=?, code=?, category=?, duration=?, base_fee=?, description=?
                        WHERE id=?
                    """, (self.name.text().strip(), self.code.text().strip() or None,
                          self.category.currentText(), self.duration.value(),
                          self.base_fee.value(), self.description.toPlainText(), self.course_id))
                else:
                    conn.execute("""
                        INSERT INTO courses (name, code, category, duration, base_fee, description)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, (self.name.text().strip(), self.code.text().strip() or None,
                          self.category.currentText(), self.duration.value(),
                          self.base_fee.value(), self.description.toPlainText()))

                QMessageBox.information(self, "موفقیت", "دوره با موفقیت ذخیره شد.")
                self.data_saved.emit()
                self.accept()
            except Exception as e:
                QMessageBox.critical(self, "خطا", f"خطا در ذخیره: {str(e)}")


# -------------------------------------------------------------------------------
# 3. ClassDialog - کلاس‌های واقعی سرای محبی
# -------------------------------------------------------------------------------
class ClassDialog(QDialog):
    data_saved = Signal()

    def __init__(self, class_id=None, parent=None):
        super().__init__(parent)
        self.class_id = class_id
        self.setWindowTitle("کلاس جدید" if not class_id else "ویرایش کلاس")
        self.setFixedSize(560, 680)
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        title = QLabel("کلاس جدید آموزشی" if not class_id else "ویرایش کلاس")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #00695c;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)

        self.name = QLineEdit()
        self.name.setPlaceholderText("مثال: رباتیک مقدماتی - گروه الف")

        self.term = QComboBox()
        self.course = QComboBox()
        self.teacher = QComboBox()
        self.capacity = QSpinBox()
        self.capacity.setRange(5, 50)
        self.capacity.setValue(15)

        self.start_date = QDateEdit()
        self.start_date.setCalendarPopup(True)
        self.start_date.setDate(QDate.currentDate())

        self.schedule = QLineEdit()
        self.schedule.setPlaceholderText("مثال: شنبه و چهارشنبه ۱۶:۰۰ تا ۱۸:۰۰")

        self.status = QComboBox()
        self.status.addItems(["برنامه‌ریزی", "در حال برگزاری", "تمام شده", "لغو شده"])

        self.class_fee = QSpinBox()
        self.class_fee.setRange(0, 20000000)
        self.class_fee.setSuffix(" تومان")
        self.class_fee.setValue(1800000)

        self.load_comboboxes()

        form.addRow("نام کلاس *", self.name)
        form.addRow("ترم *", self.term)
        form.addRow("دوره *", self.course)
        form.addRow("مربی *", self.teacher)
        form.addRow("ظرفیت کلاس", self.capacity)
        form.addRow("تاریخ شروع", self.start_date)
        form.addRow("برنامه هفتگی *", self.schedule)
        form.addRow("وضعیت کلاس", self.status)
        form.addRow("شهریه این کلاس", self.class_fee)

        layout.addLayout(form)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(self.save_class)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

        if class_id:
            self.load_class()

    def load_comboboxes(self):
        with db_connection() as conn:
            terms = conn.execute("SELECT id, name FROM terms ORDER BY start_date DESC").fetchall()
            for t in terms:
                self.term.addItem(t["name"], t["id"])

            courses = conn.execute("SELECT id, name FROM courses").fetchall()
            for c in courses:
                self.course.addItem(c["name"], c["id"])

            teachers = conn.execute("SELECT id, full_name FROM personnel WHERE role LIKE '%مربی%'").fetchall()
            for t in teachers:
                self.teacher.addItem(t["full_name"], t["id"])

    def load_class(self):
        with db_connection() as conn:
            cls = conn.execute("SELECT * FROM classes WHERE id = ?", (self.class_id,)).fetchone()
            if cls:
                self.name.setText(cls["name"])
                self.term.setCurrentIndex(self.term.findData(cls["term_id"]))
                self.course.setCurrentIndex(self.course.findData(cls["course_id"]))
                self.teacher.setCurrentIndex(self.teacher.findData(cls["teacher_id"]))
                self.capacity.setValue(cls["capacity"] or 15)
                self.status.setCurrentText(cls["status"] or "برنامه‌ریزی")
                self.class_fee.setValue(cls["fee"] or 1800000)
                self.schedule.setText(cls["schedule"] or "")
                if cls["start_date"]:
                    y, m, d = map(int, cls["start_date"].split('-'))
                    self.start_date.setDate(QDate(y, m, d))

    def save_class(self):
        if not all([self.name.text().strip(), self.schedule.text().strip()]):
            QMessageBox.warning(self, "خطا", "نام کلاس و برنامه هفتگی اجباری هستند!")
            return

        with db_connection() as conn:
            try:
                if self.class_id:
                    conn.execute("""
                        UPDATE classes SET name=?, term_id=?, course_id=?, teacher_id=?, capacity=?,
                        start_date=?, schedule=?, status=?, fee=?
                        WHERE id=?
                    """, (
                        self.name.text().strip(),
                        self.term.currentData(),
                        self.course.currentData(),
                        self.teacher.currentData(),
                        self.capacity.value(),
                        self.start_date.date().toString("yyyy-MM-dd"),
                        self.schedule.text().strip(),
                        self.status.currentText(),
                        self.class_fee.value(),
                        self.class_id
                    ))
                else:
                    conn.execute("""
                        INSERT INTO classes 
                        (name, term_id, course_id, teacher_id, capacity, start_date, schedule, status, fee)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        self.name.text().strip(),
                        self.term.currentData(),
                        self.course.currentData(),
                        self.teacher.currentData(),
                        self.capacity.value(),
                        self.start_date.date().toString("yyyy-MM-dd"),
                        self.schedule.text().strip(),
                        self.status.currentText(),
                        self.class_fee.value()
                    ))
                QMessageBox.information(self, "موفقیت", "کلاس با موفقیت ذخیره شد.")
                self.data_saved.emit()
                self.accept()
            except Exception as e:
                QMessageBox.critical(self, "خطا", f"خطا در ذخیره: {str(e)}")
                

