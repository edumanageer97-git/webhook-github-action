from PySide6.QtWidgets import (QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout, QMessageBox, QFormLayout, QComboBox, QDateEdit, QTextEdit, 
QTableWidget, QTableWidgetItem, QHeaderView)
from PySide6.QtCore import Qt
# ایمپورت‌های استاندارد برای همه دیالوگ‌ها
from PySide6.QtWidgets import (
    QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout,
    QMessageBox, QFormLayout, QComboBox, QDateEdit, QTextEdit,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QGridLayout,
    QCheckBox, QSpinBox, QDoubleSpinBox, QFileDialog, QProgressBar
)
from PySide6.QtCore import Qt, QDate, Signal
from PySide6.QtGui import QFont, QPixmap, QIcon
class AddPersonnelDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("افزودن پرسنل جدید")
        self.setFixedSize(600, 700)

        layout = QFormLayout(self)

        self.full_name = QLineEdit()
        self.phone = QLineEdit()
        self.national_id = QLineEdit()
        self.role = QComboBox()
        self.role.addItems(["مدیر ارشد", "مدیر داخلی", "مربی", "حسابدار", "ادمین پذیرش", "مشاور فروش"])
        self.base_salary = QSpinBox(); self.base_salary.setRange(5000000, 100000000); self.base_salary.setValue(15000000)
        self.class_percentage = QSpinBox(); self.class_percentage.setRange(0, 50); self.class_percentage.setValue(15)
        self.hire_date = QDateEdit(); self.hire_date.setDate(QDate.currentDate())

        layout.addRow("نام و نام خانوادگی *", self.full_name)
        layout.addRow("شماره تماس *", self.phone)
        layout.addRow("کد ملی", self.national_id)
        layout.addRow("نقش در سیستم *", self.role)
        layout.addRow("حقوق ثابت (تومان)", self.base_salary)
        layout.addRow("درصد از درآمد کلاس", self.class_percentage)
        layout.addRow("تاریخ استخدام", self.hire_date)

        btns = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        btns.accepted.connect(self.save)
        btns.rejected.connect(self.reject)
        layout.addRow(btns)

    def save(self):
        with db_connection() as conn:
            code = f"MH{str(conn.execute('SELECT COUNT(*)+1 FROM personnel').fetchone()[0]).zfill(4)}"
            conn.execute("""
                INSERT INTO personnel 
                (full_name, phone, national_id, role, base_salary, class_percentage, hire_date, personnel_code, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
            """, (
                self.full_name.text(), self.phone.text(), self.national_id.text(),
                self.role.currentText(), self.base_salary.value(), self.class_percentage.value(),
                self.hire_date.date().toString("yyyy-MM-dd"), code
            ))
        QMessageBox.information(self, "موفقیت", f"پرسنل با کد {code} اضافه شد!")
        self.accept()
