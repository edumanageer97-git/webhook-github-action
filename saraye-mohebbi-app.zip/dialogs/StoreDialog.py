
from PySide6.QtWidgets import (
    QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout,
    QMessageBox, QFormLayout, QComboBox, QDateEdit, QTextEdit,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QGridLayout,
    QCheckBox, QSpinBox, QDoubleSpinBox, QFileDialog, QProgressBar
)
from PySide6.QtCore import Qt, QDate, Signal
from PySide6.QtGui import QFont, QPixmap, QIcon
class StoreDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("فروشگاه و انبار سرای محبی")
        self.setFixedSize(1200, 720)

        layout = QVBoxLayout(self)

        # تب‌ها
        tabs = QTabWidget()
        tabs.addTab(self.create_inventory_tab(), "انبار و موجودی")
        tabs.addTab(self.create_sales_tab(), "فروش سریع")
        tabs.addTab(self.create_reports_tab(), "گزارشات انبار")
        layout.addWidget(tabs)

    # ===================================================================
    # تب 1: انبار و موجودی
    # ===================================================================
    def create_inventory_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # ابزارها
        tools = QHBoxLayout()
        tools.addWidget(QLabel("جستجو:"))
        search = QLineEdit()
        search.setPlaceholderText("نام محصول، کد یا دسته‌بندی...")
        search.textChanged.connect(self.filter_inventory)
        tools.addWidget(search)

        add_btn = QPushButton("محصول جدید")
        add_btn.setStyleSheet("background:#00695c; color:white; padding:8px;")
        add_btn.clicked.connect(self.add_product)
        tools.addWidget(add_btn)
        tools.addStretch()
        layout.addLayout(tools)

        # جدول موجودی
        self.inventory_table = QTableWidget()
        self.inventory_table.setColumnCount(9)
        self.inventory_table.setHorizontalHeaderLabels([
            "کد", "نام محصول", "دسته‌بندی", "قیمت خرید", "قیمت فروش", "موجودی", "حداقل موجودی", "وضعیت", "عملیات"
        ])
        self.inventory_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.inventory_table)

        self.load_inventory()
        return widget

    def load_inventory(self, filter_text=""):
        with db_connection() as conn:
            query = """
                SELECT p.id, p.code, p.name, p.category, p.purchase_price, p.sale_price,
                       p.stock, p.min_stock, p.expiry_date
                FROM products p WHERE 1=1
            """
            if filter_text:
                query += f" AND (p.name LIKE '%{filter_text}%' OR p.code LIKE '%{filter_text}%' OR p.category LIKE '%{filter_text}%')"
            query += " ORDER BY p.name"

            products = conn.execute(query).fetchall()

        self.inventory_table.setRowCount(len(products))
        for row, p in enumerate(products):
            self.inventory_table.setItem(row, 0, QTableWidgetItem(p["code"] or "-"))
            self.inventory_table.setItem(row, 1, QTableWidgetItem(p["name"]))
            self.inventory_table.setItem(row, 2, QTableWidgetItem(p["category"]))
            self.inventory_table.setItem(row, 3, QTableWidgetItem(f"{p['purchase_price']:,}"))
            self.inventory_table.setItem(row, 4, QTableWidgetItem(f"{p['sale_price']:,}"))
            self.inventory_table.setItem(row, 5, QTableWidgetItem(str(p["stock"])))
            self.inventory_table.setItem(row, 6, QTableWidgetItem(str(p["min_stock"])))

            status = "کم موجودی" if p["stock"] <= p["min_stock"] else "موجود"
            status_item = QTableWidgetItem(status)
            status_item.setForeground(Qt.red if status == "کم موجودی" else Qt.darkGreen)
            self.inventory_table.setItem(row, 7, status_item)

            btn_widget = QWidget()
            btn_layout = QHBoxLayout(btn_widget)
            btn_layout.setContentsMargins(5,5,5,5)

            edit_btn = QPushButton("ویرایش")
            edit_btn.clicked.connect(lambda _, pid=p["id"]: self.edit_product(pid))
            delete_btn = QPushButton("حذف")
            delete_btn.clicked.connect(lambda _, pid=p["id"]: self.delete_product(pid))

            btn_layout.addWidget(edit_btn)
            btn_layout.addWidget(delete_btn)
            self.inventory_table.setCellWidget(row, 8, btn_widget)

    def filter_inventory(self, text):
        self.load_inventory(text)

    def add_product(self):
        dlg = ProductDialog(parent=self)
        if dlg.exec():
            self.load_inventory()

    def edit_product(self, product_id):
        dlg = ProductDialog(product_id, parent=self)
        if dlg.exec():
            self.load_inventory()

    def delete_product(self, product_id):
        if QMessageBox.question(self, "تأیید", "آیا از حذف این محصول اطمینان دارید؟") == QMessageBox.Yes:
            with db_connection() as conn:
                conn.execute("DELETE FROM products WHERE id = ?", (product_id,))
            self.load_inventory()


    # ===================================================================
    # تب 2: فروش سریع (پذیرش)
    # ===================================================================
    def create_sales_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        top = QHBoxLayout()
        top.addWidget(QLabel("جستجو محصول:"))
        self.search_product = QLineEdit()
        self.search_product.setPlaceholderText("نام یا کد محصول...")
        self.search_product.textChanged.connect(self.search_products_for_sale)
        top.addWidget(self.search_product, 1)

        self.customer_name = QLineEdit()
        self.customer_name.setPlaceholderText("نام خریدار (اختیاری)")
        top.addWidget(QLabel("خریدار:"))
        top.addWidget(self.customer_name)
        layout.addLayout(top)

        # سبد خرید
        self.cart_table = QTableWidget()
        self.cart_table.setColumnCount(6)
        self.cart_table.setHorizontalHeaderLabels(["کد", "محصول", "قیمت", "تعداد", "جمع", "حذف"])
        self.cart_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.cart_table)

        # جمع کل
        bottom = QHBoxLayout()
        self.total_label = QLabel("جمع کل: ۰ تومان")
        self.total_label.setStyleSheet("font-size:18px; font-weight:bold; color:#00695c;")
        bottom.addStretch()
        bottom.addWidget(self.total_label)

        print_btn = QPushButton("چاپ فاکتور و ثبت فروش")
        print_btn.setStyleSheet("background:#00695c; color:white; padding:12px; font-size:16px;")
        print_btn.clicked.connect(self.print_invoice)
        bottom.addWidget(print_btn)
        layout.addLayout(bottom)

        return widget

    def search_products_for_sale(self, text):
        if len(text) < 2:
            return
        with db_connection() as conn:
            products = conn.execute("""
                SELECT id, code, name, sale_price, stock FROM products
                WHERE (name LIKE ? OR code LIKE ?) AND stock > 0
                LIMIT 15
            """, (f"%{text}%", f"%{text}%")).fetchall()

        menu = QMenu()
        for p in products:
            action = menu.addAction(f"{p['name']} - {p['sale_price']:,} تومان (موجودی: {p['stock']})")
            action.triggered.connect(lambda _, pid=p["id"], name=p["name"], price=p["sale_price"]: self.add_to_cart(pid, name, price))
        menu.exec(self.search_product.mapToGlobal(self.search_product.rect().bottomLeft()))

    def add_to_cart(self, product_id, name, price):
        row = self.cart_table.rowCount()
        self.cart_table.insertRow(row)

        self.cart_table.setItem(row, 0, QTableWidgetItem(str(product_id)))
        self.cart_table.setItem(row, 1, QTableWidgetItem(name))
        self.cart_table.setItem(row, 2, QTableWidgetItem(f"{price:,}"))

        qty = QSpinBox()
        qty.setRange(1, 100)
        qty.setValue(1)
        qty.valueChanged.connect(self.update_total)
        self.cart_table.setCellWidget(row, 3, qty)

        total_item = QTableWidgetItem(f"{price:,}")
        total_item.setData(Qt.UserRole, price)
        self.cart_table.setItem(row, 4, total_item)

        remove_btn = QPushButton("حذف")
        remove_btn.clicked.connect(lambda _, r=row: self.remove_from_cart(r))
        self.cart_table.setCellWidget(row, 5, remove_btn)

        self.update_total()

    def remove_from_cart(self, row):
        self.cart_table.removeRow(row)
        self.update_total()

    def update_total(self):
        total = 0
        for row in range(self.cart_table.rowCount()):
            price = self.cart_table.item(row, 4).data(Qt.UserRole)
            qty = self.cart_table.cellWidget(row, 3).value()
            total += price * qty
            self.cart_table.item(row, 4).setText(f"{price * qty:,}")
        self.total_label.setText(f"جمع کل: {total:,} تومان")

    def print_invoice(self):
        if self.cart_table.rowCount() == 0:
            QMessageBox.warning(self, "خطا", "سبد خرید خالی است!")
            return

        # ثبت فروش
        with db_connection() as conn:
            for row in range(self.cart_table.rowCount()):
                pid = int(self.cart_table.item(row, 0).text())
                qty = self.cart_table.cellWidget(row, 3).value()
                conn.execute("UPDATE products SET stock = stock - ? WHERE id = ?", (qty, pid))
                conn.execute("""
                    INSERT INTO sales (product_id, quantity, sale_price, customer_name, sale_date)
                    VALUES (?, ?, ?, ?, datetime('now'))
                """, (pid, qty, self.cart_table.item(row, 2).text().replace(",", ""), self.customer_name.text()))

        # چاپ فاکتور
        printer = QPrinter(QPrinter.HighResolution)
        dialog = QPrintDialog(printer, self)
        if dialog.exec():
            # اینجا می‌تونی فاکتور زیبا با QTextDocument بسازی
            QMessageBox.information(self, "موفقیت", "فاکتور چاپ شد و موجودی کسر گردید!")

        self.cart_table.setRowCount(0)
        self.customer_name.clear()
        self.update_total()
        self.load_inventory()


    # ===================================================================
    # تب 3: گزارشات انبار
    # ===================================================================
    def create_reports_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.addWidget(QLabel("گزارشات انبار در نسخه بعدی اضافه میشه:"))
        layout.addWidget(QLabel("• محصولات کم‌موجودی"))
        layout.addWidget(QLabel("• پرفروش‌ترین محصولات"))
        layout.addWidget(QLabel("• موجودی کل انبار"))
        layout.addStretch()
        return widget


# -------------------------------------------------------------------------------
# دیالوگ اضافه/ویرایش محصول
# -------------------------------------------------------------------------------
class ProductDialog(QDialog):
    def __init__(self, product_id=None, parent=None):
        super().__init__(parent)
        self.product_id = product_id
        self.setWindowTitle("محصول جدید" if not product_id else "ویرایش محصول")
        self.setFixedSize(500, 580)

        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.name = QLineEdit()
        self.code = QLineEdit()
        self.code.setPlaceholderText("اختیاری - مثال: ROB-KIT-01")

        self.category = QComboBox()
        self.category.addItems([
            "پک رباتیک", "کیت شطرنج", "کتاب آموزشی", "لوازم تحریر", "لباس فرم",
            "پک المپیاد", "تجهیزات سفالگری", "تجهیزات نقاشی", "سایر"
        ])

        self.purchase_price = QSpinBox()
        self.purchase_price.setRange(0, 10000000)
        self.purchase_price.setSuffix(" تومان")

        self.sale_price = QSpinBox()
        self.sale_price.setRange(0, 20000000)
        self.sale_price.setSuffix(" تومان")
        self.sale_price.setValue(1800000)

        self.stock = QSpinBox()
        self.stock.setRange(0, 10000)
        self.stock.setValue(10)

        self.min_stock = QSpinBox()
        self.min_stock.setRange(1, 100)
        self.min_stock.setValue(5)

        self.description = QTextEdit()
        self.description.setMaximumHeight(80)

        form.addRow("نام محصول *", self.name)
        form.addRow("کد محصول", self.code)
        form.addRow("دسته‌بندی *", self.category)
        form.addRow("قیمت خرید", self.purchase_price)
        form.addRow("قیمت فروش *", self.sale_price)
        form.addRow("موجودی اولیه", self.stock)
        form.addRow("حداقل موجودی", self.min_stock)
        form.addRow("توضیحات", self.description)

        layout.addLayout(form)

        btns = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        btns.accepted.connect(self.save_product)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

        if product_id:
            self.load_product()

    def load_product(self):
        with db_connection() as conn:
            p = conn.execute("SELECT * FROM products WHERE id = ?", (self.product_id,)).fetchone()
            if p:
                self.name.setText(p["name"])
                self.code.setText(p["code"] or "")
                self.category.setCurrentText(p["category"])
                self.purchase_price.setValue(p["purchase_price"])
                self.sale_price.setValue(p["sale_price"])
                self.stock.setValue(p["stock"])
                self.min_stock.setValue(p["min_stock"])
                self.description.setPlainText(p["description"] or "")

    def save_product(self):
        if not all([self.name.text().strip(), self.sale_price.value()]):
            QMessageBox.warning(self, "خطا", "فیلدهای ستاره‌دار اجباری هستند!")
            return

        with db_connection() as conn:
            if self.product_id:
                conn.execute("""
                    UPDATE products SET name=?, code=?, category=?, purchase_price=?, sale_price=?,
                    stock=?, min_stock=?, description=?
                    WHERE id=?
                """, (self.name.text().strip(), self.code.text().strip() or None,
                      self.category.currentText(), self.purchase_price.value(),
                      self.sale_price.value(), self.stock.value(), self.min_stock.value(),
                      self.description.toPlainText(), self.product_id))
            else:
                conn.execute("""
                    INSERT INTO products (name, code, category, purchase_price, sale_price, stock, min_stock, description)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (self.name.text().strip(), self.code.text().strip() or None,
                      self.category.currentText(), self.purchase_price.value(),
                      self.sale_price.value(), self.stock.value(), self.min_stock.value(),
                      self.description.toPlainText()))

        QMessageBox.information(self, "موفقیت", "محصول با موفقیت ذخیره شد.")
        self.accept()

