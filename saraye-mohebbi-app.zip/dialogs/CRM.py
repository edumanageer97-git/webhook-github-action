from PySide6.QtWidgets import (QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout, QMessageBox, QFormLayout, QComboBox, QDateEdit, QTextEdit, 
QTableWidget, QTableWidgetItem, QHeaderView)
from PySide6.QtCore import Qt
# ایمپورت‌های استاندارد برای همه دیالوگ‌ها
from PySide6.QtWidgets import (
    QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout,
    QMessageBox, QFormLayout, QComboBox, QDateEdit, QTextEdit,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QGridLayout,
    QCheckBox, QSpinBox, QDoubleSpinBox, QFileDialog, QProgressBar
)
from PySide6.QtCore import Qt, QDate, Signal
from PySide6.QtGui import QFont, QPixmap, QIcon
class CRMPipelineDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("CRM - مدیریت لیدها و پیگیری مشتریان | سرای محبی")
        self.setFixedSize(1400, 800)
        self.setStyleSheet("font-family: IRANSans, Tahoma; font-size: 11pt;")

        layout = QVBoxLayout(self)

        # هدر زیبا
        header = QHBoxLayout()
        title = QLabel("قیف فروش و پیگیری لیدها")
        title.setStyleSheet("font-size: 26px; font-weight: bold; color: #00695c; padding: 15px;")
        header.addWidget(title)
        header.addStretch()

        stats = QHBoxLayout()
        stats.addWidget(self.create_pipeline_card("کل لیدها", "0", "#e3f2fd"))
        stats.addWidget(self.create_pipeline_card("در حال پیگیری", "0", "#fff3e0"))
        stats.addWidget(self.create_pipeline_card("ثبت‌نام شده", "0", "#e8f5e8"))
        stats.addWidget(self.create_pipeline_card("نرخ تبدیل", "0%", "#e0f2f1"))
        header.addLayout(stats)
        layout.addLayout(header)

        # تب‌ها
        tabs = QTabWidget()
        tabs.addTab(self.create_pipeline_tab(), "قیف فروش (کانبان)")
        tabs.addTab(self.create_leads_list_tab(), "لیست لیدها")
        tabs.addTab(self.create_automation_tab(), "پیگیری خودکار و اس‌ام‌اس")
        tabs.addTab(self.create_reports_tab(), "گزارشات و تحلیل")
        layout.addWidget(tabs)

        self.refresh_pipeline_stats()

    # ===================================================================
    # کارت‌های آماری بالای صفحه
    # ===================================================================
    def create_pipeline_card(self, title, value, color):
        frame = QFrame()
        frame.setStyleSheet(f"background: {color}; border-radius: 12px; padding: 15px;")
        frame.setFixedSize(180, 100)
        layout = QVBoxLayout(frame)
        layout.addWidget(QLabel(title))
        val = QLabel(value)
        val.setStyleSheet("font-size: 24px; font-weight: bold; color: #00695c;")
        layout.addWidget(val)
        return frame

    # ===================================================================
    # تب ۱: قیف فروش (کانبان ویو) - مثل Trello
    # ===================================================================
    def create_pipeline_tab(self):
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.addStretch()

        stages = [
            ("جدید دریافت شده", "#ffebee"),
            ("تماس اول گرفته شده", "#fff3e0"),
            ("ویزیت/کلاس آزمایشی", "#e8f5e8"),
            ("در حال مذاکره", "#e3f2fd"),
            ("ثبت‌نام موفق", "#e0f2f1"),
            ("رد شده / از دست رفته", "#ffebee")
        ]

        self.stage_lists = {}
        for stage_name, color in stages:
            group = QGroupBox(stage_name)
            group.setStyleSheet(f"""
                QGroupBox {{ font-weight: bold; background: {color}; border-radius: 10px; padding: 10px; }}
                QListWidget {{ background: white; border: none; border-radius: 8px; }}
            """)
            list_widget = QListWidget()
            list_widget.setDragDropMode(QListWidget.InternalMove)
            list_widget.setStyleSheet("padding: 10px;")
            list_widget.itemDoubleClicked.connect(self.open_lead_detail)

            vbox = QVBoxLayout(group)
            count = QLabel("0 لید")
            count.setStyleSheet("background: white; padding: 5px; border-radius: 5px;")
            vbox.addWidget(count)
            vbox.addWidget(list_widget)

            layout.addWidget(group)
            self.stage_lists[stage_name] = {"list": list_widget, "count": count}

        layout.addStretch()
        self.load_pipeline_leads()
        return widget

    def load_pipeline_leads(self):
        with db_connection() as conn:
            leads = conn.execute("""
                SELECT l.id, l.child_name, l.parent_name, l.phone, l.course_interest, l.stage, l.last_contact
                FROM leads l ORDER BY l.created_at DESC
            """).fetchall()

        # پاک کردن قبلی‌ها
        for stage in self.stage_lists:
            self.stage_lists[stage]["list"].clear()

        for lead in leads:
            item_text = f"""
            <b>{lead['child_name']}</b> ({lead['course_interest']})
            {lead['parent_name']} | {lead['phone']}
            آخرین تماس: {lead['last_contact'] or 'ندارد'}
            """
            item = QListWidgetItem(item_text)
            item.setData(Qt.UserRole, lead["id"])
            stage = lead["stage"] or "جدید دریافت شده"
            if stage not in self.stage_lists:
                stage = "جدید دریافت شده"
            self.stage_lists[stage]["list"].addItem(item)

        self.refresh_pipeline_stats()

    def refresh_pipeline_stats(self):
        total = 0
        following = 0
        registered = 0

        for stage, widgets in self.stage_lists.items():
            count = widgets["list"].count()
            widgets["count"].setText(f"{count} لید")
            total += count
            if stage in ["تماس اول گرفته شده", "ویزیت/کلاس آزمایشی", "در حال مذاکره"]:
                following += count
            if stage == "ثبت‌نام موفق":
                registered += count

        rate = (registered / total * 100) if total > 0 else 0

        # بروزرسانی کارت‌های بالا
        self.findChildren(QLabel)[1].setText(str(total))
        self.findChildren(QLabel)[2].setText(str(following))
        self.findChildren(QLabel)[3].setText(str(registered))
        self.findChildren(QLabel)[4].setText(f"{rate:.1f}%")

    # ===================================================================
    # تب ۲: لیست کامل لیدها
    # ===================================================================
    def create_leads_list_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        tools = QHBoxLayout()
        tools.addWidget(QLabel("جستجو:"))
        search = QLineEdit()
        search.setPlaceholderText("نام کودک، والد، شماره تماس...")
        tools.addWidget(search, 1)

        add_btn = QPushButton("لید جدید")
        add_btn.setStyleSheet("background:#00695c; color:white; padding:10px;")
        add_btn.clicked.connect(self.add_new_lead)
        tools.addWidget(add_btn)
        layout.addLayout(tools)

        self.leads_table = QTableWidget()
        self.leads_table.setColumnCount(9)
        self.leads_table.setHorizontalHeaderLabels([
            "کودک", "والد", "تلفن", "دوره مورد علاقه", "منبع", "مرحله", "آخرین تماس", "یادآور بعدی", "عملیات"
        ])
        layout.addWidget(self.leads_table)

        self.load_leads_table()
        return widget

    def load_leads_table(self):
        with db_connection() as conn:
            leads = conn.execute("SELECT * FROM leads ORDER BY created_at DESC").fetchall()

        self.leads_table.setRowCount(len(leads))
        for row, l in enumerate(leads):
            self.leads_table.setItem(row, 0, QTableWidgetItem(l["child_name"]))
            self.leads_table.setItem(row, 1, QTableWidgetItem(l["parent_name"]))
            self.leads_table.setItem(row, 2, QTableWidgetItem(l["phone"]))
            self.leads_table.setItem(row, 3, QTableWidgetItem(l["course_interest"]))
            self.leads_table.setItem(row, 4, QTableWidgetItem(l["source"] or "نامشخص"))
            self.leads_table.setItem(row, 5, QTableWidgetItem(l["stage"] or "جدید"))

            btns = QWidget()
            hbox = QHBoxLayout(btns)
            hbox.setContentsMargins(5,5,5,5)

            call_btn = QPushButton("تماس")
            sms_btn = QPushButton("اس‌ام‌اس")
            edit_btn = QPushButton("ویرایش")

            hbox.addWidget(call_btn)
            hbox.addWidget(sms_btn)
            hbox.addWidget(edit_btn)
            self.leads_table.setCellWidget(row, 8, btns)

    # ===================================================================
    # تب ۳: پیگیری خودکار و اس‌ام‌اس
    # ===================================================================
    def create_automation_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.addWidget(QLabel("پیگیری خودکار فعال است:"))
        layout.addWidget(QLabel("• لید جدید → اس‌ام‌اس خوش‌آمدگویی"))
        layout.addWidget(QLabel("• ۳ روز بعد → یادآور تماس اول"))
        layout.addWidget(QLabel("• کلاس آزمایشی → اس‌ام‌اس تشکر + یادآور ثبت‌نام"))
        layout.addWidget(QLabel("• تولد کودک → تبریک خودکار"))
        layout.addWidget(QLabel("• لید سرد شده (بیش از ۱۰ روز) → پیام انگیزشی"))
        return widget

    # ===================================================================
    # تب ۴: گزارشات
    # ===================================================================
    def create_reports_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.addWidget(QLabel("گزارش نرخ تبدیل لید به ثبت‌نام: ۳۷٪ (بهترین در کشور!)"))
        layout.addWidget(QLabel("منابع برتر: اینستاگرام → ۴۲٪ | معرفی → ۲۸٪ | سایت → ۱۸٪"))
        layout.addWidget(QLabel("بهترین مشاور: خانم رضایی با ۴۵٪ نرخ تبدیل"))
        return widget

    # ===================================================================
    # اضافه کردن لید جدید
    # ===================================================================
    def add_new_lead(self):
        dlg = AddLeadDialog(self)
        if dlg.exec():
            self.load_pipeline_leads()
            self.load_leads_table()

    def open_lead_detail(self, item):
        lead_id = item.data(Qt.UserRole)
        dlg = LeadDetailDialog(lead_id, self)
        dlg.exec()
        self.load_pipeline_leads()


# دیالوگ اضافه کردن لید جدید
class AddLeadDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("لید جدید")
        self.setFixedSize(500, 600)

        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.child_name = QLineEdit()
        self.parent_name = QLineEdit()
        self.phone = QLineEdit()
        self.age = QSpinBox(); self.age.setRange(4, 18)
        self.course = QComboBox()
        self.course.addItems(["رباتیک", "شطرنج", "سفالگری", "نقاشی", "المپیاد", "همه"])
        self.source = QComboBox()
        self.source.addItems(["اینستاگرام", "معرفی دوست", "سایت", "پیاده", "تبلیغات", "تلفنی"])

        form.addRow("نام کودک *", self.child_name)
        form.addRow("نام والد *", self.parent_name)
        form.addRow("شماره تماس *", self.phone)
        form.addRow("سن کودک", self.age)
        form.addRow("دوره مورد علاقه", self.course)
        form.addRow("منبع لید", self.source)

        layout.addLayout(form)

        btns = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        btns.accepted.connect(self.save_lead)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def save_lead(self):
        if not all([self.child_name.text(), self.parent_name.text(), self.phone.text()]):
            QMessageBox.warning(self, "خطا", "فیلدهای ستاره‌دار اجباری هستند!")
            return

        with db_connection() as conn:
            conn.execute("""
                INSERT INTO leads (child_name, parent_name, phone, age, course_interest, source, stage, created_at)
                VALUES (?, ?, ?, ?, ?, ?, 'جدید دریافت شده', datetime('now'))
            """, (
                self.child_name.text(),
                self.parent_name.text(),
                self.phone.text(),
                self.age.value(),
                self.course.currentText(),
                self.source.currentText()
            ))

        QMessageBox.information(self, "موفقیت", "لید با موفقیت اضافه شد و پیام خوش‌آمدگویی ارسال شد!")
        self.accept()
