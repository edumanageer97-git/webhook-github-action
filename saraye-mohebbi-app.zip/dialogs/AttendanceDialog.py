from PySide6.QtWidgets import (QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout, QMessageBox, QFormLayout, QComboBox, QDateEdit, QTextEdit, 
QTableWidget, QTableWidgetItem, QHeaderView)
from PySide6.QtCore import Qt
# ایمپورت‌های استاندارد برای همه دیالوگ‌ها
from PySide6.QtWidgets import (
    QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout,
    QMessageBox, QFormLayout, QComboBox, QDateEdit, QTextEdit,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QGridLayout,
    QCheckBox, QSpinBox, QDoubleSpinBox, QFileDialog, QProgressBar
)
from PySide6.QtCore import Qt, QDate, Signal
from PySide6.QtGui import QFont, QPixmap, QIcon
from utils import send_sms
class AttendanceDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("حضور و غیاب کلاس - سرای محبی")
        self.setFixedSize(1100, 740)
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        # پس‌زمینه اصلی
        self.bg = QWidget(self)
        self.bg.setStyleSheet("""
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                stop:0 #e0f8f5, stop:1 #b2dfdb);
            border-radius: 30px;
            border: 4px solid white;
        """)
        self.bg.resize(1100, 740)

        layout = QVBoxLayout(self)
        layout.addWidget(self.bg)
        layout.setContentsMargins(20, 20, 20, 40)

        main_layout = QVBoxLayout(self.bg)
        main_layout.setContentsMargins(50, 50, 50, 50)
        main_layout.setSpacing(30)

        # ========== هدر ==========
        header = QHBoxLayout()
        logo = QLabel()
        logo.setPixmap(QPixmap("logo.png").scaled(80, 80, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        logo.setStyleSheet("background: white; border-radius: 40px; padding: 8px;")

        title = QLabel("حضور و غیاب کلاس")
        title.setStyleSheet("color: #00695c; font-size: 38px; font-weight: bold;")
        title.setFont(QFont("Vazir", 38, QFont.Bold))

        today = QDate.currentDate().toString("yyyy/MM/dd")
        date_label = QLabel(f"امروز: {today}")
        date_label.setStyleSheet("color: #004d40; font-size: 20px; background: white; padding: 12px 30px; border-radius: 30px;")

        header.addWidget(logo)
        header.addWidget(title)
        header.addStretch()
        header.addWidget(date_label)
        main_layout.addLayout(header)

        # ========== انتخاب کلاس ==========
        class_box = QGroupBox("انتخاب کلاس")
        class_box.setStyleSheet("""
            QGroupBox { 
                font-size: 22px; font-weight: bold; color: #00695c;
                border: 3px dashed #00695c; border-radius: 25px; 
                padding: 20px; margin-top: 20px;
            }
            QGroupBox::title { padding: 10px 30px; background: white; border-radius: 20px; }
        """)
        class_layout = QHBoxLayout(class_box)

        self.class_combo = QComboBox()
        self.class_combo.addItems([
            "رباتیک مقدماتی - شنبه ۱۶:۰۰",
            "شطرنج حرفه‌ای - دوشنبه ۱۷:۳۰",
            "برنامه‌نویسی پایتون - سه‌شنبه ۱۸:۰۰",
            "المپیاد ریاضی - چهارشنبه ۱۶:۳۰",
            "سفالگری کودکان - پنجشنبه ۱۵:۰۰"
        ])
        self.class_combo.setStyleSheet("padding: 18px; font-size: 18px; border-radius: 25px; border: 3px solid #00695c;")
        self.class_combo.setFixedHeight(70)

        refresh_btn = QPushButton("بارگذاری دانش‌آموزان")
        refresh_btn.setStyleSheet("background: #00695c; color: white; padding: 18px 35px; border-radius: 30px; font-size: 16px;")
        refresh_btn.clicked.connect(self.load_students)

        class_layout.addWidget(self.class_combo)
        class_layout.addWidget(refresh_btn)
        main_layout.addWidget(class_box)

        # ========== لیست دانش‌آموزان ==========
        self.students_list = QListWidget()
        self.students_list.setStyleSheet("""
            QListWidget { 
                background: white; border-radius: 25px; 
                padding: 20px; font-size: 18px; 
                border: 3px solid #b2dfdb;
            }
            QListWidget::item { 
                padding: 20px; margin: 8px; 
                border-radius: 20px; background: #e8f5e8;
            }
            QListWidget::item:selected { background: #00695c; color: white; }
        """)
        self.students_list.setSpacing(10)
        main_layout.addWidget(self.students_list, 1)

        # ========== دکمه‌های پایین ==========
        bottom = QHBoxLayout()
        bottom.addStretch()

        present_all = QPushButton("همه حاضر")
        present_all.setStyleSheet("background: #25d366; color: white; padding: 18px 40px; border-radius: 30px; font-size: 18px;")
        present_all.clicked.connect(lambda: self.set_all_status("حاضر"))

        absent_all = QPushButton("همه غایب")
        absent_all.setStyleSheet("background: #d32f2f; color: white; padding: 18px 40px; border-radius: 30px; font-size: 18px;")
        absent_all.clicked.connect(lambda: self.set_all_status("غایب"))

        save_btn = QPushButton("ذخیره حضور و غیاب")
        save_btn.setStyleSheet("""
            background: #00695c; color: white; 
            padding: 22px 50px; border-radius: 35px; 
            font-size: 22px; font-weight: bold; 
            border: 4px solid white;
        """)
        save_btn.clicked.connect(self.save_attendance)

        bottom.addWidget(present_all)
        bottom.addWidget(absent_all)
        bottom.addWidget(save_btn)
        main_layout.addLayout(bottom)

        # بارگذاری اولیه (دامی دیتا)
        self.load_students()

    def load_students(self):
        self.students_list.clear()
        students = [
            ("علی رضایی", "پسر", "پیش‌دبستانی"),
            ("زهرا محمدی", "دختر", "اول"),
            ("امیرحسین کریمی", "پسر", "دوم"),
            ("فاطمه حسینی", "دختر", "سوم"),
            ("محمد طاهری", "پسر", "چهارم"),
            ("نازنین یوسفی", "دختر", "پنجم"),
            ("رضا احمدی", "پسر", "ششم"),
        ]

        for name, gender, grade in students:
            item = QListWidgetItem()
            widget = QWidget()
            layout = QHBoxLayout(widget)
            layout.setContentsMargins(20, 15, 20, 15)

            # عکس دانش‌آموز (تصادفی)
            photo = QLabel()
            photo.setFixedSize(90, 90)
            pix = QPixmap(90, 90)
            pix.fill(Qt.transparent)
            painter = QPainter(pix)
            painter.setRenderHint(QPainter.Antialiasing)
            painter.setBrush(QColor("#00695c"))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(10, 10, 70, 70)
            painter.setFont(QFont("Vazir", 11, QFont.Bold))
            painter.setPen(Qt.white)
            painter.drawText(pix.rect(), Qt.AlignCenter, name[0] + ".")
            painter.end()
            photo.setPixmap(pix)
            photo.setStyleSheet("border-radius: 45px;")

            # اطلاعات
            info = QLabel(f"<b style='font-size:20px;'>{name}</b><br>{gender} • {grade}")
            info.setStyleSheet("color: #004d40;")

            # دکمه‌های حضور و غیاب
            status_group = QButtonGroup(widget)
            status_group.setExclusive(True)

            present = QRadioButton("حاضر")
            present.setStyleSheet("font-size: 18px; color: #25d366;")
            absent = QRadioButton("غایب")
            absent.setStyleSheet("font-size: 18px; color: #d32f2f;")
            late = QRadioButton("تأخیر")
            late.setStyleSheet("font-size: 18px; color: #ff9800;")

            present.setChecked(True)
            status_group.addButton(present)
            status_group.addButton(absent)
            status_group.addButton(late)

            layout.addWidget(photo)
            layout.addWidget(info, 1)
            layout.addWidget(present)
            layout.addWidget(absent)
            layout.addWidget(late)
            layout.addStretch()

            item.setSizeHint(widget.sizeHint())
            self.students_list.addItem(item)
            self.students_list.setItemWidget(item, widget)

    def set_all_status(self, status):
        for i in range(self.students_list.count()):
            item = self.students_list.item(i)
            widget = self.students_list.itemWidget(item)
            if status == "حاضر":
                widget.findChildren(QRadioButton)[0].setChecked(True)
            elif status == "غایب":
                widget.findChildren(QRadioButton)[1].setChecked(True)

    def save_attendance(self):
        QMessageBox.information(self, "موفقیت", 
            f"<h3 style='color:#00695c;'>حضور و غیاب با موفقیت ذخیره شد!</h3>"
            f"<p>کلاس: {self.class_combo.currentText()}</p>"
            f"<p>تعداد دانش‌آموز: {self.students_list.count()}</p>"
            f"<p>تاریخ: {QDate.currentDate().toString('yyyy/MM/dd')}</p>"
        )
        self.accept()

