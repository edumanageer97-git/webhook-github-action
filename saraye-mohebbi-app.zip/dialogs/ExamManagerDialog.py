from PySide6.QtWidgets import (QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout, QMessageBox, QFormLayout, QComboBox, QDateEdit, QTextEdit, 
QTableWidget, QTableWidgetItem, QHeaderView)
from PySide6.QtCore import Qt
# ایمپورت‌های استاندارد برای همه دیالوگ‌ها
from PySide6.QtWidgets import (
    QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout,
    QMessageBox, QFormLayout, QComboBox, QDateEdit, QTextEdit,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QGridLayout,
    QCheckBox, QSpinBox, QDoubleSpinBox, QFileDialog, QProgressBar
)
from PySide6.QtCore import Qt, QDate, Signal
from PySide6.QtGui import QFont, QPixmap, QIcon
class ExamManagerDialog(QDialog):
    def __init__(self, teacher_id=None, parent=None):
        super().__init__(parent)
        self.teacher_id = teacher_id
        self.setWindowTitle("مدیریت آزمون‌ها - مربی")
        self.setFixedSize(1100, 720)

        layout = QVBoxLayout(self)

        # هدر
        header = QHBoxLayout()
        title = QLabel("آزمون‌های من")
        title.setStyleSheet("font-size: 20px; font-weight: bold; color: #00695c;")
        header.addWidget(title)
        header.addStretch()

        new_btn = QPushButton("ایجاد آزمون جدید")
        new_btn.setStyleSheet("background: #00695c; color: white; padding: 10px;")
        new_btn.clicked.connect(self.create_new_exam)
        header.addWidget(new_btn)
        layout.addLayout(header)

        # جدول آزمون‌ها
        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels([
            "عنوان آزمون", "کلاس", "دوره", "تاریخ برگزاری", "وضعیت", "تعداد شرکت‌کننده", "عملیات"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)

        self.load_exams()

    def load_exams(self):
        with db_connection() as conn:
            exams = conn.execute("""
                SELECT e.id, e.title, c.name AS class_name, co.name AS course_name,
                       e.exam_date, e.is_active, 
                       (SELECT COUNT(*) FROM exam_submissions s WHERE s.exam_id = e.id) AS participants
                FROM exams e
                JOIN classes c ON e.class_id = c.id
                JOIN courses co ON c.course_id = co.id
                WHERE c.teacher_id = ?
                ORDER BY e.exam_date DESC
            """, (self.teacher_id,)).fetchall()

        self.table.setRowCount(len(exams))
        for row, exam in enumerate(exams):
            self.table.setItem(row, 0, QTableWidgetItem(exam["title"]))
            self.table.setItem(row, 1, QTableWidgetItem(exam["class_name"]))
            self.table.setItem(row, 2, QTableWidgetItem(exam["course_name"]))
            self.table.setItem(row, 3, QTableWidgetItem(exam["exam_date"]))
            status = "فعال" if exam["is_active"] else "تمام شده"
            self.table.setItem(row, 4, QTableWidgetItem(status))
            self.table.setItem(row, 5, QTableWidgetItem(str(exam["participants"])))

            btn_widget = QWidget()
            btn_layout = QHBoxLayout(btn_widget)
            btn_layout.setContentsMargins(5, 5, 5, 5)

            edit_btn = QPushButton("سؤالات")
            edit_btn.clicked.connect(lambda _, eid=exam["id"]: self.edit_questions(eid))
            view_btn = QPushButton("بررسی پاسخ‌ها")
            view_btn.clicked.connect(lambda _, eid=exam["id"]: self.review_submissions(eid))

            btn_layout.addWidget(edit_btn)
            btn_layout.addWidget(view_btn)
            self.table.setCellWidget(row, 6, btn_widget)

    def create_new_exam(self):
        dlg = CreateExamDialog(self.teacher_id, self)
        if dlg.exec():
            self.load_exams()

    def edit_questions(self, exam_id):
        dlg = EditQuestionsDialog(exam_id, self)
        dlg.exec()
        self.load_exams()

    def review_submissions(self, exam_id):
        dlg = ReviewSubmissionsDialog(exam_id, self)
        dlg.exec()
        
class CreateExamDialog(QDialog):
    def __init__(self, teacher_id, parent=None):
        super().__init__(parent)
        self.teacher_id = teacher_id
        self.setWindowTitle("ایجاد آزمون جدید")
        self.setFixedSize(500, 400)

        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.title = QLineEdit()
        self.class_combo = QComboBox()
        self.load_classes()
        self.exam_date = QDateTimeEdit()
        self.exam_date.setDateTime(QDateTime.currentDateTime())
        self.exam_date.setCalendarPopup(True)
        self.duration = QSpinBox()
        self.duration.setRange(10, 180)
        self.duration.setSuffix(" دقیقه")
        self.duration.setValue(45)

        form.addRow("عنوان آزمون *", self.title)
        form.addRow("کلاس *", self.class_combo)
        form.addRow("تاریخ و ساعت برگزاری *", self.exam_date)
        form.addRow("مدت زمان آزمون", self.duration)

        layout.addLayout(form)

        btns = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        btns.accepted.connect(self.save_exam)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def load_classes(self):
        with db_connection() as conn:
            classes = conn.execute("""
                SELECT c.id, c.name, co.name AS course 
                FROM classes c JOIN courses co ON c.course_id = co.id
                WHERE c.teacher_id = ?
            """, (self.teacher_id,)).fetchall()
            for cls in classes:
                self.class_combo.addItem(f"{cls['name']} - {cls['course']}", cls["id"])

    def save_exam(self):
        if not self.title.text().strip():
            QMessageBox.warning(self, "خطا", "عنوان آزمون الزامی است!")
            return

        with db_connection() as conn:
            conn.execute("""
                INSERT INTO exams (title, class_id, exam_date, duration_minutes, is_active, created_by)
                VALUES (?, ?, ?, ?, 1, ?)
            """, (
                self.title.text().strip(),
                self.class_combo.currentData(),
                self.exam_date.dateTime().toString("yyyy-MM-dd hh:mm"),
                self.duration.value(),
                self.teacher_id
            ))
        QMessageBox.information(self, "موفقیت", "آزمون با موفقیت ایجاد شد.\nحالا می‌تونی سؤالات رو اضافه کنی.")
        self.accept()


# -------------------------------------------------------------------------------
# 3. ویرایش سؤالات آزمون (مربی)
# -------------------------------------------------------------------------------
class EditQuestionsDialog(QDialog):
    def __init__(self, exam_id, parent=None):
        super().__init__(parent)
        self.exam_id = ...
        self.setWindowTitle("سؤالات آزمون")
        self.setFixedSize(900, 650)

        # اینجا بعداً سیستم drag & drop یا فرم اضافه کردن سؤال اضافه میشه
        # فعلاً یه پیام ساده
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f"ویرایش سؤالات آزمون ID: {exam_id}"))
        layout.addWidget(QLabel("این بخش در نسخه کامل با افزودن سؤالات تستی/تشریحی/فایل و ... تکمیل میشه"))

        close_btn = QPushButton("بستن")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)


# -------------------------------------------------------------------------------
# 4. بررسی پاسخ‌ها و ثبت نمره (مربی)
# -------------------------------------------------------------------------------
class ReviewSubmissionsDialog(QDialog):
    def __init__(self, exam_id, parent=None):
        super().__init__(parent)
        self.exam_id = exam_id
        self.setWindowTitle("بررسی پاسخ‌های فراگیران")
        self.setFixedSize(1000, 700)

        layout = QVBoxLayout(self)

        title = QLabel("پاسخ‌های ارسالی")
        title.setStyleSheet("font-size: 18px; font-weight: bold;")
        layout.addWidget(title)

        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels([
            "فراگیر", "زمان ارسال", "نمره", "وضعیت", "فایل پاسخ", "ثبت نمره"
        ])
        layout.addWidget(self.table)

        self.load_submissions()

        close_btn = QPushButton("بستن")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

    def load_submissions(self):
        with db_connection() as conn:
            submissions = conn.execute("""
                SELECT s.id, s.student_id, st.full_name, s.submitted_at, s.score, s.file_path
                FROM exam_submissions s
                JOIN students st ON s.student_id = st.id
                WHERE s.exam_id = ?
            """, (self.exam_id,)).fetchall()

        self.table.setRowCount(len(submissions))
        for row, sub in enumerate(submissions):
            self.table.setItem(row, 0, QTableWidgetItem(sub["full_name"]))
            self.table.setItem(row, 1, QTableWidgetItem(sub["submitted_at"]))
            
            score_edit = QSpinBox()
            score_edit.setRange(0, 100)
            if sub["score"]: score_edit.setValue(int(sub["score"]))
            score_edit.valueChanged.connect(lambda v, sid=sub["id"]: self.update_score(sid, v))
            self.table.setCellWidget(row, 2, score_edit)

            self.table.setItem(row, 3, QTableWidgetItem("بررسی شده" if sub["score"] is not None else "در انتظار"))

            if sub["file_path"]:
                view_btn = QPushButton("مشاهده فایل")
                view_btn.clicked.connect(lambda _, path=sub["file_path"]: self.open_file(path))
                self.table.setCellWidget(row, 4, view_btn)

    def update_score(self, submission_id, score):
        with db_connection() as conn:
            conn.execute("UPDATE exam_submissions SET score = ? WHERE id = ?", (score, submission_id))

    def open_file(self, path):
        import os
        os.startfile(path)  # ویندوز


# -------------------------------------------------------------------------------
# 5. شرکت در آزمون (فراگیر)
# -------------------------------------------------------------------------------
class TakeExamDialog(QDialog):
    def __init__(self, student_id, exam_id, parent=None):
        super().__init__(parent)
        self.student_id = student_id
        self.exam_id = exam_id
        self.setWindowTitle("شرکت در آزمون")
        self.setFixedSize(900, 700)
        self.setModal(True)

        # اینجا فرم آزمون با تایمر + آپلود پاسخ + ارسال
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("اینجا فرم آزمون نمایش داده میشه"))
        layout.addWidget(QLabel("تایمر، سؤالات، آپلود فایل پاسخ و ..."))

        submit_btn = QPushButton("ارسال پاسخ نهایی")
        submit_btn.clicked.connect(self.submit_exam)
        layout.addWidget(submit_btn)

    def submit_exam(self):
        # ذخیره پاسخ و فایل
        QMessageBox.information(self, "موفقیت", "آزمون با موفقیت ارسال شد!")
        self.accept()


# -------------------------------------------------------------------------------
# 6. مشاهده نتایج آزمون (فراگیر)
# -------------------------------------------------------------------------------
class ExamResultsDialog(QDialog):
    def __init__(self, student_id, parent=None):
        super().__init__(parent)
        self.student_id = student_id
        self.setWindowTitle("نتایج آزمون‌های من")
        self.setFixedSize(1000, 600)

        layout = QVBoxLayout(self)
        title = QLabel("کارنامه آزمون‌ها")
        title.setStyleSheet("font-size: 20px; font-weight: bold; color: #00695c;")
        layout.addWidget(title)

        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels([
            "آزمون", "کلاس", "تاریخ", "نمره", "میانگین کلاس", "رتبه"
        ])
        layout.addWidget(self.table)

        self.load_results()

    def load_results(self):
        with db_connection() as conn:
            results = conn.execute("""
                SELECT e.title, c.name AS class_name, e.exam_date, s.score
                FROM exam_submissions s
                JOIN exams e ON s.exam_id = e.id
                JOIN classes c ON e.class_id = c.id
                WHERE s.student_id = ? AND s.score IS NOT NULL
                ORDER BY e.exam_date DESC
            """, (self.student_id,)).fetchall()

        self.table.setRowCount(len(results))
        for row, res in enumerate(results):
            self.table.setItem(row, 0, QTableWidgetItem(res["title"]))
            self.table.setItem(row, 1, QTableWidgetItem(res["class_name"]))
            self.table.setItem(row, 2, QTableWidgetItem(res["exam_date"]))
            self.table.setItem(row, 3, QTableWidgetItem(str(res["score"]) if res["score"] else "در حال بررسی"))


