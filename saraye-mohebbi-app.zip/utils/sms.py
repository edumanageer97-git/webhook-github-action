# utils/sms.py - فقط برای حالت تست (کد تو کنسول چاپ می‌شه)
import random

def send_verification_code(phone: str, code: str) -> bool:
    """
    در حالت تست: کد رو تو کنسول نشون می‌ده
    وقتی پنل پیامک خریدی، اینجا کد واقعی کاوه‌نگار یا ملی‌پیامک رو بذار
    """
    print(f"\nکد تأیید برای {phone}: {code}\n")
    return True

# اگه بعداً پنل پیامک خریدی، اینو فعال کن:
# import requests
# KAVENEGAR_API = "YOUR_API_KEY"
# def send_verification_code(phone: str, code: str) -> bool:
#     url = f"https://api.kavenegar.com/v1/{KAVENEGAR_API}/verify/lookup.json"
#     payload = {"receptor": phone, "token": code, "template": "verify"}
#     try:
#         r = requests.get(url, params=payload, timeout=10)
#         return r.status_code == 200
#     except:
#         return False