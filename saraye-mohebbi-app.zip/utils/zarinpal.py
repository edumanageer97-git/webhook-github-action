# utils/zarinpal.py - نسخه نهایی با دامنه واقعی
import requests

MERCHANT_ID = "a8736a58-029d-40de-90df-7c4677391493"   # مرچنت تو
CALLBACK_URL = "https://sarayemohebbi.ir/verify_payment"  # دامنه واقعی تو
ZARINPAL_REQUEST = "https://api.zarinpal.com/pg/v4/payment/request.json"
ZARINPAL_VERIFY = "https://api.zarinpal.com/pg/v4/payment/verify.json"
ZARINPAL_START = "https://www.zarinpal.com/pg/StartPay/"

def send_request(amount: int, description: str, mobile: str = None):
    payload = {
        "merchant_id": MERCHANT_ID,
        "amount": amount,                    # به تومان
        "callback_url": CALLBACK_URL,
        "description": description,
        "metadata": {"mobile": mobile or ""}
    }
    try:
        r = requests.post(ZARINPAL_REQUEST, json=payload, timeout=10)
        data = r.json()
        if data["data"]["code"] == 100:
            authority = data["data"]["authority"]
            return f"{ZARINPAL_START}{authority}"
        else:
            return None
    except:
        return None

def verify_payment(authority: str, amount: int):
    payload = {
        "merchant_id": MERCHANT_ID,
        "authority": authority,
        "amount": amount
    }
    try:
        r = requests.post(ZARINPAL_VERIFY, json=payload, timeout=10)
        data = r.json()
        if data["data"]["code"] in [100, 101]:
            ref_id = data["data"]["ref_id"]
            return True, str(ref_id)
        else:
            return False, None
    except:
        return False, None