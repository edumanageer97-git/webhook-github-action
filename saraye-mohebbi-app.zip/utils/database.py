# utils/database.py
import sqlite3
import os
from contextlib import contextmanager

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "database", "db.sqlite3")

def init_db():
    """ساخت دیتابیس و جدول‌ها در صورت عدم وجود"""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    
    with sqlite3.connect(DB_PATH) as conn:
        with open("database/schema.sql", "r", encoding="utf-8") as f:
            conn.executescript(f.read())
        
        # ایجاد کاربر مدیر ارشد پیش‌فرض (یک بار)
        conn.execute("""
            INSERT OR IGNORE INTO users (username, password, role) 
            VALUES ('admin', '1234', 'مدیر ارشد')
        """)

@contextmanager
def db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()