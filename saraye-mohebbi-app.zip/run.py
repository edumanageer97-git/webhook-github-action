# run.py — فایل اصلی برای اجرای پروژه
from admin_panel import admin_bp
from flask import Flask

app = Flask(__name__)
app.secret_key = "saraye_mohebbi_secret_1404"

# ثبت Blueprint ادمین
app.register_blueprint(admin_bp)

if __name__ == '__main__':
    print("سرای محبی — پنل مدیریت در حال اجراست...")
    print("برو به آدرس: http://127.0.0.1:5000/admin")
    app.run(debug=True, port=5000)