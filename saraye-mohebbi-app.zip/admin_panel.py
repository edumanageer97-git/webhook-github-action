# admin_panel.py — پنل کامل مدیریت آموزشگاه سرای محبی
from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from functools import wraps
from khayyam import JalaliDatetime
import os

admin_bp = Blueprint('admin', __name__, template_folder='templates')

# دکوراتور برای چک کردن لاگین ادمین
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get('admin') != True:
            flash("لطفاً ابتدا وارد پنل مدیریت شوید.", "warning")
            return redirect(url_for('admin.login_page'))
        return f(*args, **kwargs)
    return decorated_function

# صفحه ورود ادمین
@admin_bp.route('/admin')
def login_page():
    return render_template('admin_login.html')

# پردازش ورود
@admin_bp.route('/admin/login', methods=['POST'])
def login():
    username = request.form.get('username', '').strip()
    password = request.form.get('password', '').strip()

    # موقتاً رمز ثابت — بعداً می‌تونیم دیتابیس کنیم
    if username == "admin" and password == "1404":
        session['admin'] = True
        session['admin_name'] = "کاپیتان سرای محبی"
        flash("خوش آمدی کاپیتان! ورود موفقیت‌آمیز بود.", "success")
        return redirect(url_for('admin.dashboard'))
    else:
        flash("نام کاربری یا رمز عبور اشتباه است!", "error")
        return redirect(url_for('admin.login_page'))

# داشبورد اصلی ادمین
@admin_bp.route('/admin/dashboard')
@admin_required
def dashboard():
    today_jalali = JalaliDatetime.now()
    today_str = today_jalali.strftime("%A %d %B %Y")
    today_hijri = today_jalali.strftime("%Y/%m/%d")

    # آمار (بعداً از دیتابیس می‌گیریم — الان ثابت)
    stats = {
        "students": 287,
        "teachers": 18,
        "staff": 6,
        "classes": 42,
        "today_classes": 6,
        "pending_parents": 12,
        "monthly_income": "۴۸,۵۰۰,۰۰۰ تومان"
    }

    reminders = [
        "تماس با والدین علی احمدی - کلاس ابتدایی ۱",
        "ارسال گزارش ماهانه به مدیریت",
        "بررسی مدارک ۳ فراگیر جدید",
        "جلسه مربیان ساعت ۱۶:۰۰",
        "تمدید بیمه پرسنل تا پایان هفته"
    ]

    return render_template('admin_dashboard.html',
                         today=today_str,
                         hijri=today_hijri,
                         stats=stats,
                         reminders=reminders)

# لیست فراگیران
@admin_bp.route('/admin/students')
@admin_required
def students_list():
    # بعداً از دیتابیس می‌گیریم — الان داده آزمایشی
    students = [
        {"id": 1, "name": "علی", "family": "احمدی", "age": 10, "class": "ابتدایی ۱", "phone": "09123456789", "status": "فعال"},
        {"id": 2, "name": "مریم", "family": "رضایی", "age": 11, "class": "ابتدایی ۲", "phone": "09121234567", "status": "فعال"},
        {"id": 3, "name": "رضا", "family": "محمدی", "age": 9, "class": "پیش‌دبستانی", "phone": "09139876543", "status": "غایب امروز"},
    ]
    return render_template('students_list.html', students=students)

# خروج از سیستم
@admin_bp.route('/admin/logout')
def logout():
    session.pop('admin', None)
    session.pop('admin_name', None)
    flash("با موفقیت خارج شدید.", "info")
    return redirect(url_for('admin.login_page'))

# صفحه تغییر رمز (اختیاری — بعداً کاملش می‌کنیم)
@admin_bp.route('/admin/change-password')
@admin_required
def change_password():
    return render_template('change_password.html')