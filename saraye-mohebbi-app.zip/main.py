from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = "saraye_mohebbi_eskooly_1404_mobile"

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if request.form.get('username') == 'admin' and request.form.get('password') == '1404':
            session['logged_in'] = True
            return redirect('/dashboard')
    if session.get('logged_in'):
        return redirect('/dashboard')
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if not session.get('logged_in'):
        return redirect('/')
    return render_template('dashboard.html')

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect('/')

if __name__ == '__main__':
    print("سرای محبی - نسخه موبایل eSkooly (دقیقاً مثل عکس آخرت) فعال شد!")
    print("آدرس: http://127.0.0.1:5000")
    print("ورود: admin | 1404")
    app.run(host='0.0.0.0', port=5000, debug=False)