-- database/schema.sql
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('مدیر ارشد', 'ادمین', 'مربی', 'والد'))
);

CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    parent_phone TEXT,
    class TEXT,
    birth_date TEXT,
    is_active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS courses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    day TEXT NOT NULL,
    time TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS enrollments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER,
    course_id INTEGER,
    is_active INTEGER DEFAULT 1,
    FOREIGN KEY(student_id) REFERENCES students(id),
    FOREIGN KEY(course_id) REFERENCES courses(id)
);

CREATE TABLE IF NOT EXISTS attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER,
    date TEXT DEFAULT (date('now')),
    status TEXT,
    time TEXT,
    exit_time TEXT,
    FOREIGN KEY(student_id) REFERENCES students(id)
);

CREATE TABLE IF NOT EXISTS parent_sessions (
    phone TEXT PRIMARY KEY,
    code TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);
-- جدول پرداخت‌های آنلاین (زرین‌پال)
CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    student_name TEXT,
    amount INTEGER NOT NULL,        -- به تومان
    ref_id TEXT,                    -- کد رهگیری زرین‌پال
    authority TEXT,                 -- کد Authority برای پیگیری
    status TEXT DEFAULT 'در انتظار', -- در انتظار / موفق / ناموفق
    payment_date TEXT DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (student_id) REFERENCES students (id)
);

-- ایندکس برای سرعت جستجو
CREATE INDEX IF NOT EXISTS idx_payments_student ON payments(student_id);
CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(payment_date);
CREATE TABLE IF NOT EXISTS staff (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    role TEXT NOT NULL, -- teacher / admin / accountant
    first_name TEXT,
    last_name TEXT,
    national_code TEXT UNIQUE,
    birth_date TEXT,
    education TEXT,
    specialty TEXT,
    salary_type TEXT, -- hourly / percentage
    salary_amount INTEGER,
    username TEXT UNIQUE,
    password_hash TEXT,
    photo_path TEXT,
    created_at DATETIME
);